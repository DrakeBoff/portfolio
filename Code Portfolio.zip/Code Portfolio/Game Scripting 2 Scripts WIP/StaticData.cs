using UnityEngine;

public class StaticData : MonoBehaviour
{
    public static float masterVolume = 1;
    public static float sfxVolume = 1;
    public static float musicVolume = 1;

    public static CharacterSO currentCharacter;
}
