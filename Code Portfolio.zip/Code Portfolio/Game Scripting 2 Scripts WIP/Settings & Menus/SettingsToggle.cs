using UnityEngine;

public class SettingsToggle : MonoBehaviour
{
    bool settingsVisible;
    public GameObject settingsPanel;
    public void ToggleSettings()
    {
        if(settingsVisible) settingsPanel.transform.localPosition = new Vector3(3000, 0, 0);
        else settingsPanel.transform.localPosition = Vector3.zero;
        settingsVisible = !settingsVisible;
    }
}
