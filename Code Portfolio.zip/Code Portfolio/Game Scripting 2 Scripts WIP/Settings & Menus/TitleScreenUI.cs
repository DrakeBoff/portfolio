using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TitleScreenUI : MonoBehaviour
{
    public TMP_Text characterName;
    public GameObject characterSprite;
    public CharacterSO defaultCharacter;

    //Settings
    public Slider master;
    public Slider sfx;
    public Slider music;

    void Start()
    {
        if (StaticData.currentCharacter == null) StaticData.currentCharacter = defaultCharacter;
        characterName.text = StaticData.currentCharacter.name;
        characterSprite.GetComponent<Image>().sprite = StaticData.currentCharacter.image;

        master.value = StaticData.masterVolume;
        sfx.value = StaticData.sfxVolume;
        music.value = StaticData.musicVolume;
    }
}
