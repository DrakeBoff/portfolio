using UnityEngine;
using UnityEngine.UI;

public class SettingsSlider : MonoBehaviour
{
    public enum type {Master, SFX, Music}
    public type sliderType;

    Slider slider;

    void Start()
    {
        slider = GetComponent<Slider>();
    }

    public void UpdateValues()
    {
        if (sliderType == type.Master)
        {
            StaticData.masterVolume = slider.value;
        }
        if (sliderType == type.SFX)
        {
            StaticData.sfxVolume = slider.value;
        }
        if (sliderType == type.Music)
        {
            StaticData.musicVolume = slider.value;
        }
    }
}
