using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeScene : MonoBehaviour
{
    public string sceneName;
    public void NewScene()
    {
        GameObject.Find("Audio Manager").GetComponent<AudioManager>().EndAudio.Invoke();
        SceneManager.LoadScene(sceneName);
    }
}
