using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class AudioManager : MonoBehaviour
{
    bool looping;
    int currentAudioIndex;
    new GameObject camera;

    public GameManager gameManager;
    public bool activeManager;

    public UnityEvent EndAudio;

    public AK.Wwise.RTPC introToLoop;

    public AK.Wwise.Event[] intros;
    public AK.Wwise.Event[] loops;

    public AK.Wwise.Event stopLoops;
    public AK.Wwise.Event stopAllAudio;

    void Start()
    {
        if(activeManager)
        {
            camera = Camera.main.gameObject;
            currentAudioIndex = Random.Range(0, intros.Length);
            intros[currentAudioIndex].Post(camera);
        }
        EndAudio.AddListener(StopAudio);
    }

    void ToggleAudioState()
    {
        if (looping) StartCoroutine(IntroToLoop());
        else StartCoroutine(LoopToIntro());
    }


    public IEnumerator IntroToLoop()
    {
        for (int i = 0; i <= 100; i++)
        {
            introToLoop.SetValue(Camera.main.gameObject, i);
            yield return new WaitForSeconds(.05f);
        }
        loops[currentAudioIndex].Post(camera);
    }

    public IEnumerator LoopToIntro()
    {
        if (gameManager.waveNumber % 5 == 1) GetNewIndex();
        intros[currentAudioIndex].Post(camera);
        for (int i = 100; i >= 0; i--)
        {
            introToLoop.SetValue(Camera.main.gameObject, i);
            yield return new WaitForSeconds(.02f);
        }
    }

    void GetNewIndex()
    {
        int newIndex = int.MaxValue;
        while (newIndex != currentAudioIndex || intros.Length == 1)
        {
            newIndex = Random.Range(0, intros.Length);
        }
        currentAudioIndex = newIndex;
    }

    public void StopAudio()
    {
       stopAllAudio.Post(camera);
    }
}
