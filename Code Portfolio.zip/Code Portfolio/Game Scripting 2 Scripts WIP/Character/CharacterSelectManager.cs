using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class CharacterSelectManager : MonoBehaviour
{
    public CharacterSO[] characterArray;
    public CharacterSO selectedCharacter;
    public GameObject scrollContent;
    public GameObject blankCharacter;

    public GameObject characterInfoText;
    public GameObject characterNameText;
    public GameObject selectedCharacterImage;

    void Start()
    {
        if(StaticData.currentCharacter != null) SetCurrentCharacter(StaticData.currentCharacter);
            
        foreach (var character in characterArray)
        {
            GameObject currentCharacter = Instantiate(blankCharacter, scrollContent.transform);
            currentCharacter.GetComponent<Character>().character = character;
            currentCharacter.GetComponent<Character>().SetValues();
            currentCharacter.GetComponent<UnityEngine.UI.Image>().sprite = currentCharacter.GetComponent<Character>().characterImage;
        }
    }

    public void SetCurrentCharacter(CharacterSO character) //Character button call
    {
        selectedCharacter = character;
        characterNameText.GetComponent<TMP_Text>().text = character.name;
        selectedCharacterImage.GetComponent<UnityEngine.UI.Image>().sprite = character.image;
        characterInfoText.GetComponent<TMP_Text>().text = $"Health: {character.health}\nAttack: {character.weapon.damage}\n" +
            $"Speed: {character.moveSpeed}\nWeapon: {character.weapon.name}";

    }

    public void SelectCharacter() // Select button calls
    {
        StaticData.currentCharacter = selectedCharacter;
    }

    
}
