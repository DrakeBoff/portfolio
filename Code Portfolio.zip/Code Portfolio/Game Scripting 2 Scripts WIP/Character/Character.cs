using UnityEngine;
using UnityEngine.UI;

public class Character : MonoBehaviour
{
    new public string name;
    public float health;
    public float moveSpeed;
    public Weapon weapon;

    public Sprite characterImage;
    public CharacterSO character;

    void Start()
    {
        SetValues();
        if (gameObject.GetComponent<Button>()) gameObject.GetComponent<Button>().onClick.AddListener(SendValues);
    }

    public void SetValues()
    {
        name = character.name;
        health = character.health;
        moveSpeed = character.moveSpeed;
        characterImage = character.image;
        weapon = character.weapon;
        weapon.GetValues();
    }

    void SendValues()
    {
        CharacterSelectManager characterManager = GameObject.Find("Character Select Manager").GetComponent<CharacterSelectManager>();
        characterManager.SetCurrentCharacter(character);
    }
}
