using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Tilemaps;
using UnityEngine.UIElements;
using static UnityEditor.PlayerSettings;
using static UnityEngine.RuleTile.TilingRuleOutput;

//Class for managing all aspects of the world, the terrain tilemap and nodes for pathfinding
public class MapManager : MonoBehaviour
{
    public GameManager gameManager;
    [Header("Nodes")]

    public LayerMask obstruction;
    public Vector2Int gridDimensions;
    public float nodeScale;
    public bool showNodes;  // FOR DEBUGGING

    public Node[,] grid;

    [Space]
    [Header("Tilemap")]

    public CustomTile[] tiles;
    public float[] perlinForTiles;
    public Tilemap floorTiles;
    public Tilemap obstructiveTiles;
    public Grid tileGrid;
    public CompositeCollider2D tileColliders;
    

    //randomize the map
    int offsetX;
    int offsetY;

    //needed to make the tiles visually line up with collisions
    Vector3 obstructiveOffset = new Vector3(.5f, .5f, 0);

    void Awake()
    {
        CreateNodeGrid();
        RandomizeOffset();
    }

    void Start()
    {
        CreateFloorTiles();
        CheckForOverlap();
        gameManager.StartGame();
        StartCoroutine(InstantiateChance());
    }

    void RandomizeOffset()
    {
        offsetX = Random.Range(0, 1000);
        offsetY = Random.Range(0, 1000);
    }
    //Creates the grid for the nodes using public variables
    void CreateNodeGrid()
    {
        grid = new Node[gridDimensions.x, gridDimensions.y];
        Vector3 center = transform.position;
        //Creates the Nodes
        for(int i = 0; i < gridDimensions.x; i++)
        {
            for(int j = 0; j < gridDimensions.y; j++)
            {
                grid[i, j] = new Node();
                Node currentNode = grid[i, j];
                currentNode.worldPosition = (new Vector3(i - (gridDimensions.x / 2), j - (gridDimensions.y / 2), 0) * nodeScale) + center;
            }
        }

        //Creates the connections
        for (int i = 0; i < gridDimensions.x; i++)
        {
            for (int j = 0; j < gridDimensions.y; j++)
            {
                if(i > 0) { AddNodeConnection(grid[i, j], grid[i - 1, j]); }
                if (j > 0) { AddNodeConnection(grid[i, j], grid[i, j - 1]); }
                if (i < gridDimensions.x - 1) { AddNodeConnection(grid[i, j], grid[i + 1, j]); }
                if (j < gridDimensions.y - 1) { AddNodeConnection(grid[i, j], grid[i, j + 1]); }
            }
        }

    }

    //Adds node to each others neighbors if not there already
    void AddNodeConnection(Node node1 , Node node2 )
    {
        if(!node1.neighbors.Contains(node2))
        {
            node1.neighbors.Add(node2);
            node2.neighbors.Add(node1);
        }
    }

    //Checks if the nodes are being overlaped by obstructive objects or tiles
    void CheckForOverlap()
    {
        for (int i = 0; i < gridDimensions.x; i++)
        {
            for (int j = 0; j < gridDimensions.y; j++)
            {
                Vector3Int tilePosition = obstructiveTiles.WorldToCell(grid[i, j].worldPosition - obstructiveOffset);
                TileBase tile = obstructiveTiles.GetTile(tilePosition);

                Collider2D collision = Physics2D.OverlapCircle(grid[i, j].worldPosition, .18f * nodeScale, obstruction);
                if (collision || tile != null) grid[i, j].obstructed = true;
            }
        }
    }

    //Shows the nodes and connections when the debug bool is checked
    void OnDrawGizmos()
    {
        if (grid == null || !showNodes) return;
        for (int i = 0; i < gridDimensions.x; i++)
        {
            for (int j = 0; j < gridDimensions.y; j++)
            {   
                if(grid[i, j].obstructed) Gizmos.color = Color.red;
                else Gizmos.color = Color.yellow;
                Gizmos.DrawSphere(grid[i, j].worldPosition, .18f * nodeScale);
                Gizmos.color = Color.white;
                for (int k = 0; k < grid[i, j].neighbors.Count - 1; k++)
                {
                    Gizmos.DrawLine(grid[i, j].worldPosition, grid[i, j].neighbors[k].worldPosition);
                }
            }
        }
    }

    //returns the closest node to the gameobject given
    public Node FindNearestNode(GameObject currentObject)
    {
        Node currentClosest = null;
        float closestDistance = Mathf.Infinity;
        Vector3 objectPosition = currentObject.transform.position;
        foreach (Node node in grid)
        {
            float distanceToNode = Vector3.Distance(node.worldPosition, objectPosition);
            if (distanceToNode < closestDistance && !node.obstructed)
            {
                closestDistance = distanceToNode;
                currentClosest = node;
                if (closestDistance < .7f * nodeScale) return currentClosest;

            }
        }
        return currentClosest;
    }

    //simple function to get the distance between two nodes
    public float DistanceBetweenNodes(Node node1, Node node2)
    {
        return (node1.worldPosition - node2.worldPosition).sqrMagnitude;
    }

    //Creates the tilemap using random generation
    void CreateFloorTiles()
    {
        Debug.Log(PerlinTileMath(new Vector2(245, 155)));
        // Makes sure the player spawns in grass
        while (PerlinTileMath(new Vector2(245, 155)) <= 1 || PerlinTileMath(new Vector2(245, 155)) >= 3)
        {
            RandomizeOffset();
        }

        //UPDATE NUMBERS WITH GRID DIMENSIONS 
        for (int i = 0; i < gridDimensions.x * nodeScale * 5; i++)
        {
            for (int j = 0; j < gridDimensions.y * nodeScale * 5; j++)
            {
                CustomTile currentTile = tiles[PerlinTileMath(new Vector2(i, j))];
                Vector3Int cellPosition = new Vector3Int((int)(i - gridDimensions.x * 1), (int)(j - gridDimensions.y * 1), 0);
                if (currentTile.tileType != CustomTile.Type.forest && currentTile.tileType != CustomTile.Type.rock)
                {
                    floorTiles.SetTile(cellPosition, currentTile);
                }
                else obstructiveTiles.SetTile(cellPosition, currentTile);
                if (currentTile.tileType == CustomTile.Type.darkGrass || currentTile.tileType == CustomTile.Type.dirt)
                {
                    gameManager.spawnerManager.CreateSpawningZone(obstructiveTiles.CellToWorld(cellPosition) + obstructiveOffset, .2f, .2f);
                }
            }
        }
        obstructiveTiles.GetComponent<TilemapCollider2D>().compositeOperation = Collider2D.CompositeOperation.Merge;
    }

    //does math to figure out the tiles value and returns the index
    //of the tile it should become
    int PerlinTileMath(Vector2 nodePosition)
    {
        int currentIndex = 0;
        Vector2 perlinCoordinates = (nodePosition + new Vector2(offsetX, offsetY)) * .018f;
        float perlinResults = Mathf.PerlinNoise(perlinCoordinates.x, perlinCoordinates.y);
        for (int i = 0; i < tiles.Length; i++)
        {
            if (perlinResults > perlinForTiles[i]) currentIndex = i;
        }
        return currentIndex;
    }

    //rolls the instantiation chance of a tile once a second
    IEnumerator InstantiateChance()
    {
        foreach (var position in floorTiles.cellBounds.allPositionsWithin)
        {
            TileBase tile = floorTiles.GetTile(position);
            if (tile is CustomTile customTile)
            {
                Vector3 worldPosition = floorTiles.GetCellCenterWorld(position);
                customTile.InstantiateUpdate(worldPosition);
            }
        }
        yield return new WaitForSeconds(1);
        StartCoroutine(InstantiateChance());
    }

}


//class for A* Pathfinding node
public class Node
{
    //Creation
    public Vector3 worldPosition;
    public List<Node> neighbors = new List<Node>();
    public bool obstructed;
    public GameObject nodePrefab;

    //Pathfinding
    public float distanceFromStart = float.MaxValue;
    public float distanceFromEnd;
    public Node parentNode; 
}


