using System.Collections.Generic;
using NUnit.Framework;
using Unity.VisualScripting;
using UnityEngine;

//Manager for spawning enemies
public class SpawnerManager : MonoBehaviour
{
    public GameManager gameManager;
    public bool showSpawningZones;
    public List<SpawningZone> spawnZones = new List<SpawningZone>();

    //Spawns an enemy object
    public void SpawnEnemy(GameObject enemy, GameObject[] playerList)
    {
        SpawningZone currentZone = spawnZones[Random.Range(0, spawnZones.Count)];
        Vector3 spawnPosition = (currentZone.position + new Vector3(Random.Range(-.5f * currentZone.width, .5f * currentZone.width), Random.Range(-.5f * currentZone.height, .5f * currentZone.height),0));
        GameObject currentEnemy = Instantiate(enemy, spawnPosition, Quaternion.identity);
        currentEnemy.GetComponent<Enemy>().playerList = playerList;
    }

    //Creates a zone for enemies to spawn in
    public void CreateSpawningZone(Vector3 position, float width, float height)
    {
        SpawningZone zone = new SpawningZone();
        zone.position = position;
        zone.width = width;
        zone.height = height;
        spawnZones.Add(zone);
    }

    //Displays the zones if the debug bool is checked
    void OnDrawGizmos()
    {
        if (showSpawningZones)
        {
            for (int i = 0; i < spawnZones.Count; i++)
            {
                SpawningZone zone = spawnZones[i];
                Gizmos.color = Color.orange;
                Gizmos.DrawCube(zone.position, new Vector3(zone.width, zone.height, 0));
            }
        }
    }
}

//class to create a box for enemies to spawn in
public class SpawningZone
{
    public Vector3 position;
    public float width;
    public float height;
    public bool inRange;
}
