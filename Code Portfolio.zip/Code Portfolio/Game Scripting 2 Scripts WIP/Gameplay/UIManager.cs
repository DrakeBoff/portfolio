using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

//Manager for the game UI
public class UIManager : MonoBehaviour
{
    public GameObject outOfCombat;
    public GameManager gameManager; 

    public TMP_Text currentWaveText;
    public TMP_Text healthText;
    public Slider healthbar;
    public Slider skipToWave;

    void Update()
    {
        if(!gameManager.inCombat)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                skipToWave.value += .003f;
                if (skipToWave.value >= 1)
                {
                    outOfCombat.SetActive(false);
                    gameManager.inCombat = true;
                }
            }
            else
            {
                skipToWave.value -= .001f;
            }
        }    
    }

    //Starts the countdown until the next wave starts
    public IEnumerator EndWave()
    {
        outOfCombat.SetActive(true);
        for (int i = 30; i > 0; i--)
        {
            outOfCombat.transform.GetChild(0).GetComponent<TMP_Text>().text = i.ToString();
            yield return new WaitForSeconds(1);
            if (gameManager.inCombat)
            {
                outOfCombat.SetActive(false);
                gameManager.waveNumber++;
                gameManager.StartWave();
                yield break;
            }
        }
        outOfCombat.SetActive(false);
        gameManager.waveNumber++;
        gameManager.StartWave();
    }

}
