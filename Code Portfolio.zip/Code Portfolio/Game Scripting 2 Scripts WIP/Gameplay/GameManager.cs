using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using TMPro;
using TMPro.EditorUtilities;
using UnityEngine;
using UnityEngine.UIElements;

//Manager that manages the game itself and nexus for other managers
public class GameManager : MonoBehaviour
{

    public SpawnerManager spawnerManager;
    public MapManager mapManager;
    public UIManager uiManager; 
    public AudioManager audioManager;
    public GameObject[] players;
    public string[] allEnemyTypes;

    [Space]
    [Header("Enemy Object Arrays")]
    public GameObject[] enemyType1;
    public GameObject[] enemyType2;
    public GameObject[] enemyType3;
    List<GameObject> enemiesToSpawn = new List<GameObject>(); //per wave

    public bool inCombat;
    public int waveNumber;
    string currentEnemyType;
    string lastEnemyType = null;

    public List<Enemy> currentEnemies = new List<Enemy>(); //alive enemies

    //Decides the new enemy type
    string GenerateNewEnemyType()
    {
        Debug.Log(Random.Range(0, allEnemyTypes.Length - 1));
        return allEnemyTypes[Random.Range(0, allEnemyTypes.Length - 1)];
    }

    //Starts the gameplay
    public void StartGame() // call after map creation
    {
        EndWave();
    }

    //Starts the wave of enemies
    public void StartWave()
    {
        StartCoroutine(audioManager.IntroToLoop());
        uiManager.currentWaveText.text = ("Wave " + waveNumber.ToString());
        Debug.Log("wave " + waveNumber + " started");
        GameObject[] enemies = enemyType1;

        float spawnRate = GenerateRate();
        int spawnAmount = GenerateAmount();

        if (waveNumber % 5 == 1) //Generate new enemytype every 5 waves
        {
            while (currentEnemyType == lastEnemyType)
            {
                Debug.Log("124234");
                currentEnemyType = GenerateNewEnemyType();
            }
            if (currentEnemyType == "zombies")
            {
                enemies = enemyType1;
            }
            lastEnemyType = currentEnemyType;
        }
        Debug.Log(enemies);
        foreach (var enemy in enemiesToSpawn) Debug.Log(enemy);
        enemiesToSpawn = CreateEnemyList(enemies, spawnAmount);
        if (waveNumber % 5 == 0) enemiesToSpawn.Add(enemies[enemies.Length - 1]); //Adds a boss at the end of every 5 waves

        StartCoroutine(SpawnEnemies(enemiesToSpawn, spawnRate));
    }

    //Starts the timer between waves
    void EndWave()
    {
        inCombat = false;
        Debug.Log("wave "+ waveNumber + " ended");
        StartCoroutine(uiManager.EndWave());
    }

    //Creates an enemy using the spawner manager
    IEnumerator SpawnEnemies(List<GameObject> enemyList, float rate)
    {
        spawnerManager.SpawnEnemy(enemyList[0], players);
        currentEnemies.Add(enemyList[0].GetComponent<Enemy>());
        enemyList.Remove(enemyList[0]);
        yield return new WaitForSeconds(rate);
        if (enemyList.Count != 0) StartCoroutine(SpawnEnemies(enemyList, rate));
    }

    //math for the rate of enemy spawn
    float GenerateRate()
    {
        return 5 - (waveNumber * .02f);
    }

    //math for the amount of enemies to spawn
    int GenerateAmount()
    {
        return 5 + (waveNumber + Random.Range(0, waveNumber));
    }

    //Creates a list of enemies to spawn for the current wave
    List<GameObject> CreateEnemyList(GameObject[] enemies, int amount)
    {
        List<GameObject> returnList = new List<GameObject>();
        for(int i = 0; i <= amount; i++)
        {
            returnList.Add(enemies[Random.Range(0, enemies.Length - 1)]);
        }
        Debug.Log(returnList);
        return returnList;
    }

    //Determines if the wave is over or not
    public void CheckForEnemies()
    {
        Debug.Log("wave " + waveNumber + " checking for enemies, current: " + currentEnemies.Count + " to spawn: " + enemiesToSpawn.Count);
        if (currentEnemies.Count == 0 && enemiesToSpawn.Count == 0) EndWave();
    }
}
