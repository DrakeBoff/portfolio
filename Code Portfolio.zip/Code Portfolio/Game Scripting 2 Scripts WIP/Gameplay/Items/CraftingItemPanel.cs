using System;
using System.Collections.Generic;
using JetBrains.Annotations;
using NUnit.Framework;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Windows.Speech;

//class for any items that can be crafted
public class CraftingItemPanel : MonoBehaviour
{
    Dictionary<string, int> items = new Dictionary<string, int>();
    public Item[] itemsNeeded;
    public GameObject itemCrafted;
    public Player player;

    [Space]
    [Header("Construct Panel")]

    public GameObject blankItemSlot;

    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
        CreatePanel();
    }

    void Update()
    {
        if(!IsCraftable())
        {
            gameObject.GetComponent<Image>().color = Color.red;
        }
        else
        {
            gameObject.GetComponent<Image>().color = Color.green;
        }
    }

    //Crafts item and uses up the resources in the players inventory
    public void CraftItem()
    {
        foreach (var item in items)
        {
            player.inventory.RemoveItems(item.Key, item.Value);
        }
        if(itemCrafted.GetComponent<Item>() != null)
        {
            player.inventory.AddItems(itemCrafted.GetComponent<Item>().name, 1);
        }
        else if (itemCrafted.GetComponent<Weapon>() != null)
        {
            itemCrafted.GetComponent<Weapon>().GetValues();
            player.inventory.AddWeapon(itemCrafted.GetComponent<Weapon>());
        }
    }

    //Creates a generic UI panel with basic information
    void CreatePanel()
    {
        for (int i = 0; i < itemsNeeded.Length; i++)
        {
            try { items[itemsNeeded[i].name] += 1; }
            catch { items.Add(itemsNeeded[i].name, 1); }
        }
        int currentIndex = 0;
        foreach (var item in items)
        {
            Vector3 pos = new Vector3(15 + (currentIndex * 45), 0, 0);
            CreateItemSlot(GetItem(item.Key), item.Value, pos);
            currentIndex++;
        }
        transform.GetChild(0).GetComponent<Image>().sprite = itemCrafted.GetComponent<SpriteRenderer>().sprite;
    }

    //Makes the image field for the item to be crafted 
    void CreateItemSlot(Item item, int amount, Vector3 position)
    {
        item.SetValues();
        GameObject currentItemSlot = Instantiate(blankItemSlot, transform.Find("Item View").transform.GetChild(0).GetChild(0));
        currentItemSlot.transform.localPosition += position;
        currentItemSlot.transform.GetChild(0).GetComponent<Image>().sprite = item.image;
        currentItemSlot.transform.GetChild(1).GetComponent<TMP_Text>().text = ("x" + amount);
    }

    //Gets an item from its name
    Item GetItem(string name)
    {
        for (int i = 0; i < itemsNeeded.Length; i++)
        {
            if (itemsNeeded[i].name == name) { return itemsNeeded[i]; }

        }
        Debug.Log("Item not found in itemsNeeded");
        return null;
    }

    //returns if the item can be crafted with the players resources
    bool IsCraftable()
    {
        foreach (var item in items)
        {
            if (player.inventory.inventory.ContainsKey(item.Key) == false) return false;
            else if (item.Value > player.inventory.inventory[item.Key]) return false;
        }
        return true;
    }

    //method called by the craft button
    public void CraftButton()
    {
        if (IsCraftable()) CraftItem();
    }
}
