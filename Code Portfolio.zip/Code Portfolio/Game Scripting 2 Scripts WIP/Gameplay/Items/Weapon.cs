using Unity.VisualScripting;
using UnityEngine;

//class for all player weapons
public class Weapon : MonoBehaviour
{
    new public string name;
    public float damage;
    public float atkSpeed;
    public string type;
    public int tier;
    public Vector2 hitbox;
    public Sprite image;
    public Sprite projectileImage;
    public float projectileSpeed;
    public bool stored;

    [Space]
    public MeleeWeaponSO melee;
    public RangedWeaponSO ranged;
    void Awake()
    {
        GetValues();
    }

    //Sets the values from the scriptable object
    //needed when the object is not yet instantated
    public void GetValues()
    {
        if (melee != null)
        {
            name = melee.name;
            damage = melee.damage;
            atkSpeed = melee.atkSpeed;
            type = melee.type;
            tier = melee.tier;
            hitbox = melee.hitbox;
            image = melee.image;
        }
        else if (ranged != null)
        {
            name = ranged.name;
            damage = ranged.damage;
            atkSpeed = ranged.atkSpeed;
            type = ranged.type;
            tier = ranged.tier;
            image = ranged.weaponImage;
            projectileImage = ranged.projectileImage;
            projectileSpeed = ranged.projectileSpeed;
        }
    }
}
