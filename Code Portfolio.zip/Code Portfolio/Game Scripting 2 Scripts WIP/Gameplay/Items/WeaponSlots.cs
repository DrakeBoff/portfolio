using TMPro;
using UnityEngine;
using UnityEngine.UI;

//Class for the 2 weapon slots in the inventory UI
public class WeaponSlots : MonoBehaviour
{
    public int slotNumber;
    public Weapon currentWeapon;

    public Player player;

    private void Start()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
    }

    //Updates the weapon in its slot to the given weapon
    public void UpdateWeaponSlot(Weapon weapon)
    {
        if (slotNumber == 1) player.equipedWeapon = weapon;
        if (slotNumber == 2) player.storedWeapon = weapon;
        weapon.stored = false;
        player.inventory.inventoryUI.GetPanel("weapon", weapon.name).GetComponent<WeaponPanel>().UpdatePanel();
        currentWeapon.stored = true;
        player.inventory.inventoryUI.GetPanel("weapon", currentWeapon.name).GetComponent<WeaponPanel>().UpdatePanel();
        (weapon, currentWeapon) = (currentWeapon, weapon);
        SetImage(weapon);
    }

    //Sets the image of the weapon slot
    public void SetImage(Weapon weapon)
    {
        gameObject.transform.GetChild(1).GetComponent<Image>().sprite = weapon.image;
    }
}
