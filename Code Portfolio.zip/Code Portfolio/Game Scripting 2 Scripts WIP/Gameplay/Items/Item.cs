using System.Collections;
using UnityEngine;

//class for all items
public class Item : MonoBehaviour
{
    public ItemSO item;
    new public string name;
    public Sprite image;
    void Start()
    {
        SetValues();
        StartCoroutine(ItemTimer());
    }

    //Sets the values from the scriptable object
    //needed when the object is not yet instantated
    public void SetValues()
    {
        name = item.name;
        image = item.image;
        gameObject.GetComponent<SpriteRenderer>().sprite = image;
    }

    //Deletes an instantiated item after a minute to not clutter the scene
    IEnumerator ItemTimer()
    {
        yield return new WaitForSeconds(60);
        Destroy(gameObject);
    }

}
