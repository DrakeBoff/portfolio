using JetBrains.Annotations;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

//class to display weapons in the inventory
public class WeaponPanel : MonoBehaviour
{
    public bool dragging;
    public bool activePanel = true;
    public Player player;

    public Weapon weapon;

    void Awake()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
    }

    //Displays the status of whether or not the weapon is currently equiped
    public void UpdatePanel()
    { 
        if (player.equipedWeapon != null && player.storedWeapon != null) Debug.Log("Current weapons: " + player.equipedWeapon.name + ", " + player.storedWeapon.name);
        if (!WeaponInHands(weapon))
        {
            Debug.Log("Weapon: " + weapon.name + " not in hands");
            gameObject.GetComponent<Image>().color = Color.white;
            activePanel = true;
        }
        else
        {
            Debug.Log("Weapon: " + weapon.name + " in hands");
            gameObject.GetComponent<Image>().color = Color.gray;
            activePanel = false;
        }
    }
    
    //Called by the equip button to set an unequiped weapon to the main weapon slot
    public void Equip()
    {
        if(!WeaponInHands(weapon) && !player.attacking)
        {
            if (player.GetComponent<Player>().storedWeapon == null)
            {
                player.GetComponent<Player>().SetWeapon(weapon, "stored");
            }
            else
            {
                player.GetComponent<Player>().SetWeapon(weapon, "equiped");
            }
            UpdatePanel();
        }
    }

    //returns if the panels weapon is in either weapon slot
    bool WeaponInHands(Weapon weapon)
    {
        if(player.equipedWeapon != null)
        {
            if (weapon == player.equipedWeapon) return true;
        }
        if (player.storedWeapon != null)
        {
            if (weapon == player.storedWeapon) return true;
        }
        return false;
    }
}
