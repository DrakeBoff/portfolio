using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using JetBrains.Annotations;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UI;
using static UnityEditor.ShaderGraph.Internal.KeywordDependentCollection;

//Class for all enemies
public class Enemy : MonoBehaviour
{
    //pathfinding
    public MapManager mapManager;
    List<Node> currentPath = new List<Node>();
    int currentPathIndex = 0;
    public bool invincible;

    public GameObject[] playerList;
    public EnemySO enemySO;

    //SO info
    new public string name;
    public float damage;
    public float atkSpeed;
    public float moveSpeed;
    public float health;
    public float range;
    public int[] coinRange;
    public Sprite image;

    [Space]
    [Header("Loot Table")]
    public GameObject[] itemDrops;
    public float[] itemChance;
    public int[] itemNumber;

    public Animator animator;
    public GameObject projectileObject;

    bool attacking;
    Slider healthBar;
    float maxHP;
    GameObject closestPlayer;
    Rigidbody2D rigid;
    GameManager gameManager;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        mapManager = GameObject.Find("Map Manager").GetComponent<MapManager>();
        gameManager = GameObject.Find("Game Manager").GetComponent<GameManager>();

        Player.enemyFindPath.AddListener(FindNearestPlayer);

        name = enemySO.name;
        damage = enemySO.damage;
        atkSpeed = enemySO.atkSpeed;
        moveSpeed = enemySO.speed;
        health = enemySO.health;
        range = enemySO.range;
        coinRange = enemySO.coinRange;
        image = enemySO.image;
        animator = gameObject.GetComponent<Animator>();
        rigid = gameObject.GetComponent<Rigidbody2D>();
        healthBar = transform.GetChild(0).transform.GetChild(0).GetComponent<Slider>();
        maxHP = health;
        FindNearestPlayer();
    }

    void Update()
    {
        if (Vector3.Distance(transform.position, closestPlayer.transform.position) <= range) Attack();
    }
    //Moves towards the player using A* pathfinding
    void FixedUpdate()
    {
        if (currentPath == null || currentPathIndex >= currentPath.Count) return;
        Vector3 targetNodePosition;
        Vector3 targetNodeDirection;

        for (int i = currentPath.Count - 1; i > currentPathIndex; i--)
        {
            targetNodePosition = currentPath[i].worldPosition;
            targetNodeDirection = (targetNodePosition - transform.position);
            float distance = targetNodeDirection.magnitude;
        }
        targetNodePosition = currentPath[currentPathIndex].worldPosition;
        targetNodeDirection = (targetNodePosition - transform.position).normalized;
        rigid.AddForce(targetNodeDirection * moveSpeed * Time.deltaTime);
        if(Vector2.Distance(transform.position, targetNodePosition) < .5f) currentPathIndex++;
    }

    //Damages enemy if hit by attack
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<Attack>())
        {
            TakeDamage(other.GetComponent<Attack>().damage, other.GetComponent<Attack>().player);
            if(other.GetComponent<Projectile>()) Destroy(other.gameObject);
        }
    }

    //Finds the closest of the players in the game (if multiplayer)
    void FindNearestPlayer()
    {
        float closestDistance = Mathf.Infinity;
        for(int i = 0;i<playerList.Length;i++)
        {
            float newDistance = Vector2.Distance(gameObject.transform.position, playerList[i].transform.position);
            if(newDistance < closestDistance)
            {
                closestDistance = newDistance;
                closestPlayer = playerList[i];
            }
        }
        CreatePath();
    }
    
    //Creates the path for the enemy to follow
    void CreatePath()
    {
        Node enemyNode = mapManager.FindNearestNode(gameObject);
        Node playerNode = mapManager.FindNearestNode(closestPlayer);
        if (enemyNode != null && playerNode != null)
        {
            List<Node> newPath = GetPath(enemyNode, playerNode);
            newPath = ImprovedPath(newPath);
            if (newPath != null)
            {
                currentPath = newPath;
                currentPathIndex = 0;
            }
        }
    }

    List<Node> GetPath(Node start, Node end)
    {
        List<Node> nodesToCheck = new List<Node>();
        HashSet<Node> checkedNodes = new HashSet<Node>();
        Dictionary<Node, float> currentCost = new Dictionary<Node, float>();
        Dictionary<Node, Node> parentList = new Dictionary<Node, Node>();

        nodesToCheck.Add(start);
        currentCost[start] = 0;

        while (nodesToCheck.Count > 0)
        {
            //Checks the distance from the start node through
            //iterations of a list of nodes to check their distance 
            Node currentNode = nodesToCheck[0];
            int currentIndex = 0;
            float currentClosest = Mathf.Infinity;  

            for (int i = 0; i < nodesToCheck.Count; i++)
            {
                float checkedTotalCost = mapManager.DistanceBetweenNodes(nodesToCheck[i], end);
                float currentTotalCost = currentCost[nodesToCheck[i]] + checkedTotalCost;
                if (currentTotalCost < currentClosest)
                {
                    currentClosest = currentTotalCost;
                    currentNode = nodesToCheck[i];
                    currentIndex = i;
                }
            }

            //There are no more paths to check
            if (currentNode == end) return FollowPath(start, end, parentList);

            nodesToCheck.RemoveAt(currentIndex);
            checkedNodes.Add(currentNode);

            //adds the neighbors to be checked if not already checked or obstructed
            //then sets values for node math at the start of the while loop
            foreach (Node neighborNode in currentNode.neighbors)
            {
                if (neighborNode.obstructed || checkedNodes.Contains(neighborNode)) continue;
                {
                    float distance = currentCost[currentNode] + mapManager.DistanceBetweenNodes(currentNode, neighborNode);
                    if (!currentCost.ContainsKey(neighborNode) || distance < currentCost[neighborNode])
                    {
                        currentCost[neighborNode] = distance;
                        parentList[neighborNode] = currentNode;
                        if (!nodesToCheck.Contains(neighborNode)) nodesToCheck.Add(neighborNode);
                    }
                }
            }
        }
        return null;
    }

    List<Node> ImprovedPath(List<Node> path)
    {
        List<Node>  newPath = new List<Node>();
        newPath.Add(path[0]);
        currentPathIndex = 0;

        while (currentPathIndex < path.Count - 1)
        {
            for (int i = path.Count - 1; i > currentPathIndex; i--)
            {
                Vector3 distanceBewtweenNodes = path[i].worldPosition - path[currentPathIndex].worldPosition;
                RaycastHit2D wallHit = Physics2D.CircleCast(path[currentPathIndex].worldPosition, gameObject.GetComponent<CapsuleCollider2D>().size.x,
                    distanceBewtweenNodes.normalized, distanceBewtweenNodes.magnitude, mapManager.obstruction);
                if (wallHit.collider == null)
                {
                    newPath.Add(path[i]);
                    currentPathIndex = i;
                    break;
                }
            }
        }
        return newPath;
    }

    List<Node> FollowPath(Node start, Node end, Dictionary<Node, Node> parentList)
    {
        List<Node> currentPath = new List<Node>();
        Node currentNode = end;
        while (currentNode != start)
        {
            currentPath.Add(currentNode);
            currentNode = parentList[currentNode];
        }
        currentPath.Reverse();
        return currentPath;
    }

    //Damages the enemy
    public void TakeDamage(float damageTaken, Player player)
    {
        if(!invincible)
        {
            health -= damageTaken;
            animator.SetTrigger("Show Health");
            healthBar.value = health / maxHP;
            if (health <= 0) Die(player);
        }
    }

    //Drops items when defeated and destroys enemy
    void Die(Player player)
    {
        Debug.Log("DEAD");
        List<GameObject> itemsToDrop = new List<GameObject>();
        for (int i = 0; i < itemDrops.Length; i++)
        {
            for (int  j = 0; j <= itemNumber[i]; j++)
            {
                if(Random.Range(0,101) >= itemChance[i]) itemsToDrop.Add(itemDrops[i]);
            }
        }
        for (int i = 0;i < itemsToDrop.Count; i++)
        {
            Vector3 varience = new Vector3(1, 1, 0) * Random.Range(-1.5f, 1.5f);
            Instantiate(itemsToDrop[i], transform.position + varience, Quaternion.identity);
        }
        player.inventory.ChangeGoldAmount(Random.Range(coinRange[0], coinRange[1]));
        gameManager.currentEnemies.Remove(gameManager.currentEnemies[0]);
        gameManager.CheckForEnemies();
        Destroy(gameObject);
    }

    void Attack()
    {
        if(!attacking) StartCoroutine(AttackEnum());
    }

    IEnumerator AttackEnum()
    {
        GameObject attackObject = transform.Find("Attack Object").gameObject;
        Vector3 attackDirection = transform.position - closestPlayer.transform.position;
        float attackRotation = Mathf.Atan2(attackDirection.y, attackDirection.x) * Mathf.Rad2Deg;

        attackObject.transform.localPosition = -(attackDirection.normalized / 3) * range;
        attackObject.transform.rotation = Quaternion.Euler(0, 0, 90 + attackRotation);
        attacking = true;
        if (projectileObject == null)
        {
            attackObject.GetComponent<EnemyAttack>().damage = damage;
            attackObject.SetActive(true);
            yield return new WaitForFixedUpdate();
            attackObject.SetActive(false);
        }
        else if (projectileObject != null)
        {
            GameObject projectile = Instantiate(projectileObject, attackObject.transform.position, attackObject.transform.rotation);
            projectile.GetComponent<EnemyAttack>().damage = damage;
        }
        yield return new WaitForSeconds(1 / atkSpeed);
        attacking = false;
    }   
}
