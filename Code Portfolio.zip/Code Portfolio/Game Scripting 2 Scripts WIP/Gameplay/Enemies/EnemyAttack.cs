using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    public float damage;
}
