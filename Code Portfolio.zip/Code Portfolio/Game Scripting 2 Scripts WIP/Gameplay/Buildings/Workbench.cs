using TMPro;
using UnityEditor.Rendering.Universal;
using UnityEngine;
using UnityEngine.UI;

public class Workbench : MonoBehaviour
{
    public GameObject[] tier1Panels;
    public GameObject[] tier2Panels;
    public GameObject[] tier3Panels;
    public GameObject[] upgradePanels;
    public bool upgradeable;

    public GameObject workbenchUI;
    public Player player;

    float currentTier = 1;
    GameObject currentUpgradePanel;
    bool inTrigger = true;

    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
        AddPanels(tier1Panels);
    }

    void Update()
    {
        if(inTrigger && Input.GetKeyDown("f")) ShowUI();
    }

    //Toggles a helper UI telling the player what button to press
    void OnTriggerEnter2D(Collider2D other)
    {
        inTrigger = true;
        if (other.gameObject.GetComponent<PlayerCollider>()) ToggleUIPreview();
    }

    void OnTriggerExit2D(Collider2D other)
    {
        inTrigger = false;
        if (other.gameObject.GetComponent<PlayerCollider>()) ToggleUIPreview();
    }

    //Adds all crafting panels to the view
    void AddPanels(GameObject[] panels)
    {
        GameObject panelView = workbenchUI.transform.GetChild(3).GetChild(0).GetChild(0).gameObject;
        for (int i = 0; i < panels.Length; i++) Instantiate(panels[i], panelView.transform);
    }

    //Upgrades the workbench to the next tier, adding the next tier recipies as well
    public void UpgradeWorkbench()
    {
        if(upgradeable)
        {
            GameObject title = workbenchUI.transform.GetChild(2).gameObject;
            GameObject upgradeButton = workbenchUI.transform.GetChild(4).gameObject;

            Destroy(currentUpgradePanel);
            currentTier++;
            if (currentTier == 2)
            {
                AddPanels(tier2Panels);
                currentUpgradePanel = Instantiate(upgradePanels[1]);
                title.GetComponent<TMP_Text>().text = "Workbench Tier 2";
                upgradeButton.transform.GetChild(0).GetComponent<TMP_Text>().text = "Upgrade to Tier 3";

            }
            else if (currentTier == 3)
            {
                AddPanels(tier3Panels);
                currentUpgradePanel = Instantiate(upgradePanels[2]);
                title.GetComponent<TMP_Text>().text = "Workbench Tier 3";
                upgradeButton.transform.GetChild(0).GetComponent<TMP_Text>().text = "Max Tier";
            }
        }
    }
    
    //toggles the helper UI
    void ToggleUIPreview()
    {
        GameObject preview = transform.GetChild(1).GetChild(0).gameObject;
        preview.SetActive(!preview.activeSelf);
    }

    //Shows the actual workbench UI
    public void ShowUI()
    {
        workbenchUI.SetActive(!workbenchUI.activeSelf);
        player.inMenu = !player.inMenu;
        player.gameManager.uiManager.gameObject.SetActive(!player.gameManager.uiManager.gameObject.activeSelf);
    }
}
