using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

//Class for all unbuilt buildings
public class Building : MonoBehaviour
{
    public Player player;
    public GameObject buildingToSpawn;
    public GameObject buildingUI;
    public Item[] itemsNeeded;
    public Dictionary<string, int> items = new Dictionary<string, int>();

    void Awake()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
        SetPanelInfo();
        for (int i = 0; i < itemsNeeded.Length; i++)
        {
            try { items[itemsNeeded[i].name] += 1; }
            catch { items.Add(itemsNeeded[i].name, 1); }
        }
    }

    //Toggle after so it can run SetPanelInfo() first
    void Start()
    {
        ToggleUI();
    }

    //Toggles the building UI if the player walks close enough
    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.GetComponent<PlayerCollider>()) ToggleUI();
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<PlayerCollider>()) ToggleUI();
    }

    //Checks if the player has the necessary items to build the building
    bool IsBuildable()
    {
        foreach (var item in items)
        {
            if (player.inventory.inventory.ContainsKey(item.Key) == false) return false; 
            else if (item.Value > player.inventory.inventory[item.Key]) return false; 
        }
        return true;
    }

    //Build the building
    public void Build()
    {
        if(IsBuildable())
        {
            Instantiate(buildingToSpawn, gameObject.transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    //Gets info from the panel object and creates the panel of the UI
    void SetPanelInfo()
    {
        CraftingItemPanel panel = buildingUI.GetComponent<CraftingItemPanel>();
        panel.itemsNeeded = itemsNeeded;
        panel.itemCrafted = buildingToSpawn;
    }

    //Toggles the UI on and off
    void ToggleUI()
    {
        GameObject canvas = transform.GetChild(0).gameObject;
        canvas.SetActive(!canvas.activeSelf);
    }
}
