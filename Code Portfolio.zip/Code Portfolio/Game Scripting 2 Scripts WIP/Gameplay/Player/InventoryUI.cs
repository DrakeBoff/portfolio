using System;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using static UnityEditor.Progress;

//Class that manages all UI elements of the inventory
public class InventoryUI : MonoBehaviour
{
    public Inventory inventory;
    public Player player;
    public GameObject blankPanel;
    public GameObject blankCraftingPanel;
    public GameObject blankWeaponPanel;
    public GameObject coinPanel;
    public GameObject weaponSlot1;
    public GameObject weaponSlot2;

    public GameObject[] craftingPanelsToAdd;

    public List<GameObject> items = new List<GameObject>();
    public List<GameObject> weapons = new List<GameObject>();

    public bool visable;

    void Start()
    {
        player = GameObject.Find("Player").GetComponent<Player>();
        for (int i = 0; i < craftingPanelsToAdd.Length; i++)
        {
            AddCraftingPanel(craftingPanelsToAdd[i]);
        }
    }

    //Either adds value to an existing panel or creates a new one if needed
    public void AddItemToUI(Item item)
    {
        item.SetValues();
        GameObject itemPanel = Instantiate(blankPanel, GetScrollerContent("item").transform);
        items.Add(itemPanel);
        itemPanel.name = ("ItemPanel" + item.name);
        itemPanel.transform.GetChild(1).GetComponent<Image>().sprite = item.image;
        ChangeAmount(item);

    }

    //changes the amount variable of an item panel
    public void ChangeAmount(Item item)
    {
        GameObject itemPanel = GetPanel("item", item.name);
        if (!inventory.inventory.ContainsKey(item.name) || inventory.inventory[item.name] < 0)
        {
            Destroy(itemPanel);
        }
        else itemPanel.transform.GetChild(0).GetComponent<TMP_Text>().text = ("x" + inventory.inventory[item.name].ToString());
    }

    //Gets the item scrollers content object given its name
    public GameObject GetScrollerContent(string name)
    {
        if(name == "item")
        {
            GameObject tempObject = gameObject.transform.GetChild(1).gameObject;
            for(int i =0; i < 3;i++)
            {
                tempObject = tempObject.transform.GetChild(0).gameObject;
            }
            return tempObject;
        }
        else if (name == "crafting")
        {
            GameObject tempObject = gameObject.transform.GetChild(2).gameObject;
            for (int i = 0; i < 3; i++)
            {
                tempObject = tempObject.transform.GetChild(0).gameObject;
            }
            return tempObject;
        }
        if (name == "weapon")
        {
            GameObject tempObject = gameObject.transform.GetChild(3).gameObject;
            for (int i = 0; i < 3; i++)
            {
                tempObject = tempObject.transform.GetChild(0).gameObject;
            }
            return tempObject;
        }
        return null;
    }

    //Toggles the inventorys UI
    public void ToggleInventoryUI()
    {
        if(visable)
        {
            gameObject.transform.position = new Vector3(2000, -275.5f, 0);
            visable = false;
        }
        else
        {
            gameObject.transform.position = Vector3.zero + new Vector3(0,-2,0);
            visable = true;
        }
        player.inMenu = !player.inMenu;
        player.gameManager.uiManager.gameObject.SetActive(!player.gameManager.uiManager.gameObject.activeSelf);
    }

    //Adds a weapon to the UI
    public void AddWeaponToUI(Weapon weapon)
    {
        GameObject weaponPanel = Instantiate(blankWeaponPanel, GetScrollerContent("weapon").transform);
        weaponPanel.GetComponent<WeaponPanel>().weapon = weapon;
        weapons.Add(weaponPanel);
        weaponPanel.name = ("weaponPanel" + weapon.name);
        weaponPanel.transform.GetChild(1).GetComponent<Image>().sprite = weapon.image;
        weaponPanel.transform.GetChild(0).GetComponent<TMP_Text>().text = weapon.name;
        weaponPanel.GetComponent<WeaponPanel>().UpdatePanel();
    }

    //Creates a new panel for the crafting tab
    void AddCraftingPanel(GameObject panelToAdd)
    {
        GameObject craftingPanel = Instantiate(panelToAdd, GetScrollerContent("crafting").transform);
    }

    //Returns a specific panel given its type and name
    public GameObject GetPanel(string type, string name)
    {
        if(type == "item")
        {
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].name == "ItemPanel" + name)
                {
                    return items[i];
                }
            }
        }
        else if (type == "weapon")
        {
            for (int i = 0; i < weapons.Count; i++)
            {
                if (weapons[i].name == "weaponPanel" + name)
                {
                    return weapons[i];
                }
            }
        }
            return null;
    }

    public void UpdateCoins(int amount)
    {
        coinPanel.transform.GetChild(2).GetComponent<TMP_Text>().text = amount.ToString();
    }
}
