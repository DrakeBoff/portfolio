using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using static UnityEditor.Progress;

//class that manages the players inventory and items
public class Inventory : MonoBehaviour
{
    public Dictionary<string, int> inventory = new Dictionary<string, int>();
    public List<Weapon> weapons = new List<Weapon>();
    public int gold;
    public GameObject[] allItems;
    [Space]
    public InventoryUI inventoryUI;
    public ItemsAddedUI itemsAddedUI;

    private void Start()
    {
        for (int i = 0; i < allItems.Length; i++)
        {
            allItems[i].GetComponent<Item>().SetValues();
        }
    }

    //Adds items to the inventory
    public void AddItems(string name, int amount)
    {
        try
        {
            inventory[name] += amount;
            inventoryUI.ChangeAmount(GetItemObject(name).GetComponent<Item>());
        }
        catch
        {
            inventory.Add(name, amount);
            inventoryUI.AddItemToUI(GetItemObject(name).GetComponent<Item>());
        }
        StartCoroutine(itemsAddedUI.AddRecentItem(GetItemObject(name).GetComponent<Item>(), amount));
    }

    

    //removes items from the inventory
    public void RemoveItems(string name, int amount)
    {
        inventory[name] -= amount;
        if (inventory[name] <= 0)
        {
            inventory.Remove(name);
        }
        inventoryUI.ChangeAmount(GetItemObject(name).GetComponent<Item>());
        
    }

    //returns item object when given its name
    public GameObject GetItemObject(string name)
    {
        for (int i = 0; i < allItems.Length; i++)
        {
            if (allItems[i].name == name)
            {
                allItems[i].GetComponent<Item>().SetValues();
                return allItems[i];
            }
        }
        return null;
    }

    //adds weapon to the inventory
    public void AddWeapon(Weapon weapon)
    {
        weapons.Add(weapon);
        inventoryUI.AddWeaponToUI(weapon);
    }

    public void ChangeGoldAmount(int amount)
    {
        gold += amount;
        inventoryUI.UpdateCoins(gold);
        StartCoroutine(itemsAddedUI.AddRecentItem(GetItemObject("Coin").GetComponent<Item>(), amount));
    }
}
