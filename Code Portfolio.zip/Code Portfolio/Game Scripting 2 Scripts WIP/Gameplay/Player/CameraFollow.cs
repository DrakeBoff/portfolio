using UnityEngine;

//Class that makes the camera follow the player with a bit of easing into it
public class CameraFollow : MonoBehaviour
{
    public Player player;
    private Vector3 referenceVelocity = Vector3.zero;
    public float easeTime;

    void Update()
    {
        transform.position = Vector3.SmoothDamp(transform.position, player.transform.position, ref referenceVelocity, easeTime);
    }
}
