using System.Net.Http.Headers;
using UnityEngine;

//Class thats mostly a tag for enemy colliders
public class Projectile : MonoBehaviour
{
    public float projectileSpeed = 1;
    public Rigidbody2D rigid;
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        rigid.linearVelocity = transform.up * projectileSpeed;
    }

    public void SetSprite(Sprite projectileSprite)
    {
        gameObject.GetComponent<SpriteRenderer>().sprite = projectileSprite;
    }
    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
