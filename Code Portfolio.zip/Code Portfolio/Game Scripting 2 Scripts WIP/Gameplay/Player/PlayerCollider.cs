using UnityEngine;

public class PlayerCollider : MonoBehaviour
{
    public Player player;
    private void OnTriggerEnter2D(Collider2D other)
    {
        //Pick up item
        if (other.GetComponent<Item>())
        {
            Item item = other.GetComponent<Item>();
            player.inventory.AddItems(item.name, 1);
            Destroy(other.gameObject);
        }

        //Pick up weapon
        else if (other.GetComponent<Weapon>())
        {
            Weapon weapon = other.GetComponent<Weapon>();
            GameObject weaponCopy = new GameObject();
            weaponCopy.AddComponent<Weapon>();
            if (weapon.melee != null)
            {
                weaponCopy.GetComponent<Weapon>().melee = weapon.melee;
            }
            if (weapon.ranged != null)
            {
                weaponCopy.GetComponent<Weapon>().ranged = weapon.ranged;
            }
            weapon = weaponCopy.GetComponent<Weapon>();
            weapon.GetValues();
            weapon.gameObject.name = ("TempObject" + weapon.name);
            weapon.gameObject.SetActive(false);

            if (player.equipedWeapon == null)
            {
                player.SetWeapon(weapon, "equiped");
            }
            else if (player.storedWeapon == null)
            {
                player.SetWeapon(weapon, "stored");
            }
            else
            {
                weapon.stored = true;
            }
            player.inventory.AddWeapon(weapon);
            Destroy(other.gameObject);

        }

        if (other.GetComponent<EnemyAttack>())
        {
            player.TakeDamage(other.GetComponent<EnemyAttack>().damage);
        }
    }
}
