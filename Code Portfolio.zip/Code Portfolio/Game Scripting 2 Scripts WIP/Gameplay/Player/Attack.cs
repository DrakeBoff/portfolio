using UnityEngine;

//Tag script that only stores the damage of the attack
public class Attack : MonoBehaviour
{
    public float damage;
    public Player player;
}
