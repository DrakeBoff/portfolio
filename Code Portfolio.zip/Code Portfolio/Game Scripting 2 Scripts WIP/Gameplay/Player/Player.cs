using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.Events;

public class Player : MonoBehaviour
{
    public float health;
    float maxHP;
    Vector3 oldPosition;
    public float moveSpeed;

    public Rigidbody2D rigid;
    public GameObject blankWeaponObject;
    public GameObject blankProjectileObject;
    public SettingsToggle settings;
    public Inventory inventory;
    public GameManager gameManager;
    [Space]
    [Header("Leave Blank")]
    public Weapon equipedWeapon;
    public Weapon storedWeapon;
    public GameObject equipedWeaponObject;


    public bool attacking;
    public bool inMenu = false;

    public static UnityEvent enemyFindPath = new UnityEvent();

    void Start()
    {
        maxHP = health;
        oldPosition = transform.position;
    }

    void Update()
    {
        if ((transform.position - oldPosition).sqrMagnitude >= 2) enemyFindPath.Invoke();
        if(Input.GetKeyDown("e")) //TOGGLE INVENTORY
        {
            inventory.inventoryUI.ToggleInventoryUI();
        }
        if (Input.GetKeyDown("q")) //SWAP WEAPONS
        {
            SwapWeapons();
        }
        if(Input.GetMouseButton(0)) //ATTACK
        {
            Attack();
        }
        if(Input.GetKeyDown("z")) //DEBUG KEY
        {
            Debug.Log(inventory.inventoryUI.weapons[0].name);
        }
        if (Input.GetKeyDown(KeyCode.Escape)) // SETTINGS
        {
            settings.ToggleSettings();
            if(!inventory.inventoryUI.visable) gameManager.uiManager.gameObject.SetActive(!gameManager.uiManager.gameObject.activeSelf);
        }
        // Makes weapon face mouse
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.up = new Vector2(mousePosition.x - transform.position.x, mousePosition.y - transform.position.y);

    }

    //Player movement
    void FixedUpdate()
    {
        if(Input.GetKey("w"))
        {
            rigid.AddForce(new Vector3(0,moveSpeed,0));
        }
        if(Input.GetKey("a"))
        {
            rigid.AddForce(new Vector3(-moveSpeed,0,0));
        }
        if(Input.GetKey("s"))
        {
            rigid.AddForce(new Vector3(0,-moveSpeed,0));
        }
        if(Input.GetKey("d"))
        {
            rigid.AddForce(new Vector3(moveSpeed,0,0));
        }
        if (!Input.GetKey("w") && !Input.GetKey("a") && !Input.GetKey("s") && !Input.GetKey("d"))
        {
            //needed for terrain colliders messing up player velocity
            rigid.linearVelocity = Vector3.zero;
            rigid.angularVelocity = 0;
        }
        //Forces constant speed so simultaneous vectors dont move faster
        rigid.linearVelocity = Vector3.ClampMagnitude(rigid.linearVelocity, moveSpeed);
    }

    //Swaps between your equiped weapon and the one in the offhand (different from being stored in the inventory)
    void SwapWeapons()
    {
        Weapon weaponE = equipedWeapon;
        Weapon weaponS = storedWeapon;
        if(!attacking)
        {
            if (weaponE == null && weaponS != null)
            {
                SetWeapon(weaponS, "equiped");
                storedWeapon = null;
            }
            else if (weaponE != null && weaponS == null)
            {
                SetWeapon(weaponE, "stored");
                equipedWeapon = null;
                Destroy(equipedWeaponObject);
            }
            else if (weaponE != null && weaponS != null)
            {
                SetWeapon(weaponE, "stored");
                SetWeapon(weaponS, "equiped");
                SetWeapon(weaponS, "equiped"); //Runs twice to make inventory UI show correctly
            }
        }
    }

    //Sets (or swaps if applicable) a weapon to the main or offhand
    public void SetWeapon(Weapon weapon, string slot)
    {
        
        if(slot == "equiped")
        {
            Weapon currentEquipedWeapon = equipedWeapon;
            equipedWeapon = weapon;
            inventory.inventoryUI.weaponSlot1.GetComponent<WeaponSlots>().SetImage(weapon);
            CreateWeaponObject(weapon);
            if (currentEquipedWeapon != null) inventory.inventoryUI.GetPanel("weapon", currentEquipedWeapon.name).GetComponent<WeaponPanel>().UpdatePanel();
            inventory.inventoryUI.weaponSlot1.transform.GetChild(1).gameObject.SetActive(true);
        }
        else if(slot == "stored")
        {
            Weapon currentStoredWeapon = storedWeapon;
            storedWeapon = weapon;
            inventory.inventoryUI.weaponSlot2.GetComponent<WeaponSlots>().SetImage(weapon);
            if (currentStoredWeapon != null) inventory.inventoryUI.GetPanel("weapon", currentStoredWeapon.name).GetComponent<WeaponPanel>().UpdatePanel();
            inventory.inventoryUI.weaponSlot2.transform.GetChild(1).gameObject.SetActive(true);
        }
        
    }

    //Creates the physical weapon the player holds
    public void CreateWeaponObject(Weapon weapon)
    {   
        if(equipedWeaponObject != null)
        {
            Destroy(equipedWeaponObject);
        }
        equipedWeaponObject = Instantiate(blankWeaponObject, transform);
        if (weapon.ranged != null) equipedWeaponObject.transform.localRotation = Quaternion.Euler(0,0,90);
        equipedWeaponObject.name = ("WeaponObject" + weapon.name);
        equipedWeaponObject.GetComponent<SpriteRenderer>().sprite = weapon.image;
        equipedWeaponObject.transform.localPosition = new Vector3(0,1,0);
        equipedWeaponObject.GetComponent<BoxCollider2D>().size = weapon.hitbox;
        equipedWeaponObject.GetComponent<Attack>().damage = weapon.damage;
        equipedWeaponObject.GetComponent<Attack>().player = this;
    }

    //Activates the AttackEnum
    void Attack()
    {
        if(!attacking && equipedWeapon != null && !inMenu)
        {
            StartCoroutine(AttackEnum());
        }
    }

    //Attacks with the equipped weapon
    IEnumerator AttackEnum()
    {
        attacking = true;
        if(equipedWeapon.melee != null) //Swing if its melee
        {
            equipedWeaponObject.GetComponent<BoxCollider2D>().enabled = true;
            for (int i = 0; i < 5; i++)
            {
                equipedWeaponObject.transform.RotateAround(transform.position, new Vector3(0, 0, 1), -6);
                yield return new WaitForSeconds(.002f / equipedWeapon.atkSpeed);
            }
            for (int i = 0; i < 30; i++)
            {
                equipedWeaponObject.transform.RotateAround(transform.position, new Vector3(0, 0, 1), (60 / 30f));
                yield return new WaitForSeconds(.004f / equipedWeapon.atkSpeed);
            }
            for (int i = 0; i < 5; i++)
            {
                equipedWeaponObject.transform.RotateAround(transform.position, new Vector3(0, 0, 1), -6);
                yield return new WaitForSeconds(.015f / equipedWeapon.atkSpeed);
            }
        }
        else if(equipedWeapon.ranged != null) //Fires a projectile if ranged
        {
            equipedWeapon.GetValues();
            float projectileSpeed = 1;
            if(equipedWeapon.projectileSpeed != 0) { projectileSpeed = equipedWeapon.projectileSpeed; }
            GameObject projectile = Instantiate(blankProjectileObject, transform.position, transform.rotation);
            projectile.GetComponent<Projectile>().SetSprite(equipedWeapon.projectileImage);
            projectile.GetComponent<Attack>().damage = equipedWeapon.damage;
            yield return new WaitForSeconds(1 / equipedWeapon.atkSpeed);
        }
        equipedWeaponObject.GetComponent<BoxCollider2D>().enabled = false;
        yield return new WaitForSeconds((1 / equipedWeapon.atkSpeed) / 1.4f);
        attacking = false;
    }

    public void TakeDamage(float damageTaken)
    {
        health -= damageTaken;
        gameManager.uiManager.healthbar.value = health / maxHP;
        gameManager.uiManager.healthText.text = (maxHP + "/\n" + health);
    }
}
