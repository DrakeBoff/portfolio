using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEditor.Searcher;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UIElements;

public class ItemsAddedUI : MonoBehaviour
{
    public List<GameObject> recentItemsObjects = new List<GameObject>();
    public List<RecentItem> recentItems = new List<RecentItem>();
    public GameObject blankItem;

    void Update()
    {
        for(int i = 0; i < recentItems.Count; i++)
        {
            GameObject currentItem = recentItemsObjects[i];
            currentItem.transform.localPosition = new Vector3(0, (-1 * (110 * i)), 0);
        }
    }

    public IEnumerator AddRecentItem(Item item, int amount)
    {
        RecentItem currentRecentItem = new RecentItem();
        currentRecentItem.item = item;
        currentRecentItem.amount = amount;
        foreach (RecentItem recent in recentItems)
        {
            if(recent.item == item)
            {
                currentRecentItem.amount += recent.amount;

                Destroy(recentItemsObjects[recentItems.IndexOf(recent)]);
                recentItemsObjects.RemoveAt(recentItems.IndexOf(recent));
                recentItems.Remove(recent);
                break;
            }
        }
        recentItems.Add(currentRecentItem);

        GameObject currentItem = Instantiate(blankItem, gameObject.transform);
        currentItem.SetActive(true);
        currentItem.transform.GetChild(0).GetComponent<UnityEngine.UI.Image>().sprite = item.image;
        currentItem.transform.GetChild(1).GetComponent<TMP_Text>().text = "x" + currentRecentItem.amount;
        recentItemsObjects.Add(currentItem);
        yield return new WaitForSeconds(2);
        recentItemsObjects.Remove(currentItem);
        recentItems.Remove(currentRecentItem);
        Destroy(currentItem);
    }
}

public class RecentItem
{
    public GameObject itemObject;
    public Item item;
    public int amount;
}