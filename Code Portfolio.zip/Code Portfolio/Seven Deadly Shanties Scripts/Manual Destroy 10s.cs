using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManualDestroy10s : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(DestroyObject());
    }
    public IEnumerator DestroyObject()
    {
        yield return new WaitForSeconds(10);
        Destroy(gameObject);
    }
}
