using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class aspectRatio : MonoBehaviour
{
    public GameObject sixteenNine;
    public GameObject sixteenTen;
    public GameObject fourThree;

    private GameObject sixteenNineI;
    private GameObject sixteenTenI;
    private GameObject fourThreeI;

    private float resRatio;
    

    //16:9 4:3 16:10
    // Start is called before the first frame update
    void Start()
    {
        StaticData.widthDiff = 1f;
        StaticData.heightDiff = 1f;
        AutoToggle();
    }
    public void AutoToggle(){
        float width = Screen.width;
        float height = Screen.height;

        resRatio = (width / height);
        if(resRatio >= 1.68888889f){
            StaticData.APtoggle = 0;
        }
        else if(resRatio >= 1.46666667f){
            StaticData.APtoggle = 1;
        }
        else{
            StaticData.APtoggle = 2;
        }
        if(StaticData.APtoggle == 0){
            //16:9
            sixteenNineI = Instantiate(sixteenNine, new Vector3(0,.55f,0), transform.rotation);
            
        }
        else if(StaticData.APtoggle == 1){
            //16:10
            sixteenTenI = Instantiate(sixteenTen, new Vector3(0,.99f,0), transform.rotation);
           
        }
        else if(StaticData.APtoggle == 2){
            //4:3 1024 x 768, 1280 x 960, and 1600 x 1200
            fourThreeI = Instantiate(fourThree, new Vector3(0,.82f,0), transform.rotation);
           
        }
        ApplyRatio(StaticData.APtoggle);
    }
    public void ChangeRatio()
    {
        StaticData.APtoggle++;
        if(StaticData.APtoggle>2){
            StaticData.APtoggle = 0;
        }
        if(StaticData.APtoggle == 0){
            //16:9
            sixteenNineI = Instantiate(sixteenNine, new Vector3(0,.55f,0), transform.rotation);
            Destroy(fourThreeI);
        }
        else if(StaticData.APtoggle == 1){
            //16:10
            sixteenTenI = Instantiate(sixteenTen, new Vector3(0,.99f,0), transform.rotation);
            Destroy(sixteenNineI);
        }
        else if(StaticData.APtoggle == 2){
            //4:3 1024 x 768, 1280 x 960, and 1600 x 1200
            fourThreeI = Instantiate(fourThree, new Vector3(0,.82f,0), transform.rotation);
            Destroy(sixteenTenI);
        }
        ApplyRatio(StaticData.APtoggle);
    }
    public void ApplyRatio(float toggle)
    {
        float width = Screen.width;
        float height = Screen.height;
        if(toggle == 0)
        {
            if(width/height < 16/9f){//Taller
                StaticData.heightDiff = (9/16f)/(height/width);
                StaticData.changedAP = true;
            }
            else if(width/height > 16/9f){//Wider
                StaticData.widthDiff = (16/9f)/(width/height);
                StaticData.changedAP = true;
            }
            else{
                StaticData.changedAP = false;
            }
        }
        else if(toggle == 1)
        {
            if(width/height < 16/10f){//Taller
                StaticData.heightDiff = (10/16f)/(height/width);
                StaticData.changedAP = true;
            }
            else if(width/height > 16/10f){//Wider
                StaticData.widthDiff = (16/10f)/(width/height);
                StaticData.changedAP = true;
            }
            else{
                StaticData.changedAP = false;
            }
        }
        else if(toggle == 2)
        {
            if(width/height < 16/12f){//Taller
                StaticData.heightDiff = (12/16f)/(height/width);
                StaticData.changedAP = true;
            }
            else if(width/height > 16/12f){//Wider
                StaticData.widthDiff = (16/12f)/(width/height);
                StaticData.changedAP = true;
            }
            else{
                StaticData.changedAP = false;
            }
        }
    }
    

}
