using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticData : MonoBehaviour
{
    public saveManager SaveManager;
    public static string difficultyToggle = "Easy";
    public static string level = "Set Sail";

    public static string percentText;
    public static string newPercentText;
    public static float highestPercent;
    public static float currentDifficultyHighest; 

    public static bool changedAP;
    public static int APtoggle;
    public static float heightDiff;
    public static float widthDiff;

    public static float subdivisionOfBeat = 3; //Meter of the Song
    public static float songBPS = .46875f;

    public static float tutorialPage;
    public static bool tutorialCompleted;

    void Start()
    {
        highestPercent = SaveManager.GetPercent(StaticData.level, StaticData.difficultyToggle);
        tutorialCompleted = SaveManager.GetTutorial();
    }

}
