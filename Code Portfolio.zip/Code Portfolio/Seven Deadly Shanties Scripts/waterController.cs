using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class waterController : MonoBehaviour
{
    public GameObject water;
    bool i = true;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(WaterSpawner());
    }

    private IEnumerator WaterSpawner()
    {
        while(i){   
            Instantiate(water,new Vector3(0,10.5f,1), transform.rotation);
            yield return new WaitForSeconds(35);
                }
    }
}
