using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OldCombatreferecne : MonoBehaviour
{

//Just in case I need to reference any of the old code so I can delete most of it 

    /* new public audioController audio;
    public camera Camera1;
    public completionPercent compPer;
    public UIcontroller UI;
    public gameOverText goText;
    public outOfBoundsText oobText;
    
    //fm .46875 seconds per beat
    public GameObject attack1;
    public GameObject attack2;
    public GameObject attack3;

    private float toggle;
    private float APratio;
    private Vector3 APscale;
   
    Rigidbody2D rigid;
    private float diffX;
    private float diffY;

    public glowcontroller Glow;

    Transform CanvasT;
    public GameObject Canvas;

    Vector3 p;
    
    public bool gameOver;

    private GameObject arrow;
    private GameObject circle;
    private GameObject beam;
    

    
   
    // Start is called before the first frame update
    void Start()
    {
        APscale = new Vector3(1,1,1);
      GetSpace(1.5f,1f);
      diffX = aspectRatio.widthDiff;
      diffY = aspectRatio.heightDiff;
      toggle = difficultyManager.difficultyToggle;
      APratio = aspectRatio.APtoggle;
      StartCombat();
        
        
        
        Time.timeScale = 1;
        CanvasT = Canvas.GetComponent<Transform>();
        if(APratio == 1){
            APscale.x = .9f;
            APscale.y = 1;
        }
        else if(APratio == 2){
            APscale.x = .75f;
            APscale.y = 1;
        }
        
    }
    

    // Update is called once per frame
    void Update()
    {
     
            
    }
    public void GetSpace(float x, float y){
        
        Camera camera1 = Camera1.GetComponent<Camera>();
        
        p = camera1.ViewportToWorldPoint(new Vector3(x, y, camera1.nearClipPlane));
        
        if(aspectRatio.changedAP == true){
            p.x *= diffX;
            p.y *= diffY;
        }
        
        
    }
    

    public void StartCombat()
    {
        if(toggle == 0) {
            StartCoroutine(StartEasy());
            Debug.Log(toggle);
        }
        else if(toggle == 1) {
            StartCoroutine(StartHard());
            Debug.Log("H");
        }
        else if(toggle == 2) {
            StartFull();
            Debug.Log("F");
        }

    }

    public void GameOver()
    {
        Debug.Log("Game Over");
        compPer.SetPercent();
        goText.GameOverPercent();
        oobText.OutofBounds();
        UI.ShowGameOver();

    }

    public IEnumerator StartEasy()
    {
        
        yield return new WaitForSeconds(.46875f*1f);
        audio.StartAudio();
        
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(BeamR(.5f,1.8f, new Vector3(-1f,-4f,0), 3, 0f, .1f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(BeamR(.5f,-.8f, new Vector3(1f,4f,0), 3, 180f, .1f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Arrow(0,.5f, new Vector3(30,0,0),.9f, 90f));
        StartCoroutine(Arrow(1,.5f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*3f);
        StartCoroutine(Arrow(0,.94f, new Vector3(30,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,.07f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.5f,.5f, new Vector3(20,20,0), 1f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Beam(-.4f,.5f, new Vector3(1.8f,0f,0), 8,1, 90f));
        StartCoroutine(Beam(1.4f,.5f, new Vector3(-1.8f,0f,0), 8,1, -90f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Circle(.5f,1f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.8f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.6f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.4f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*9.5f);
        //End of intro
        StartCoroutine(Circle(.8f,.2f, new Vector3(20,20,0), 1.5f));    
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.3f,.4f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.5f,.7f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.1f,.6f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.7f,.6f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(BeamP(.5f,1.8f, new Vector3(0f,-3f,0), 15,0f));
        StartCoroutine(BeamP(.5f,-.8f, new Vector3(0f,3f,0), 15,180f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-30,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(0f,1, new Vector3(0,-30,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-30,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-30,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-30,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(BeamPScaled(1f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(0f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*2f); 
        StartCoroutine(BeamPScaled(.345f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(.655f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(BeamPScaled(.5f,.75f, new Vector3(0f,0f,0),new Vector3(200,15,0), 2,0f));
        StartCoroutine(BeamPScaled(.5f,.25f, new Vector3(0f,0f,0),new Vector3(200,15,0), 2,0f));   
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(BeamPScaled(.24f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(.76f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Beam(-.4f,-.4f, new Vector3(1.5f,1.5f,0), 7,1, -45f));
        StartCoroutine(Beam(1.4f,1.4f, new Vector3(-1.5f,-1.5f,0), 7,1, -45f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Beam(-.4f,1.4f, new Vector3(2.5f,-2.5f,0), 3,1, 45f));
        StartCoroutine(Beam(1.4f,-.4f, new Vector3(-2.5f,2.5f,0), 3,1, 45f)); 
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(1,0, new Vector3(-30,20,0),1, 60f));
        StartCoroutine(Arrow(0,0, new Vector3(30,20,0),1, -60f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(0,1f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(0,.635f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Beam(.5f,-.8f, new Vector3(0,5f,0), 3,1, 180f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Arrow(.3f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(.7f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(.1f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(.9f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(-.1f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(1.1f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,1, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,.8f, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,.6f, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 1.5f,0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(1,0, new Vector3(-30,20,0),1, 60f));
        StartCoroutine(Arrow(0,0, new Vector3(30,20,0),1, -60f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(0,0, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(0,.365f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Beam(.5f,1.8f, new Vector3(0,-5f,0), 3,1, 0f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(BeamP(1.4f,.5f, new Vector3(-5f,0,0), 3.5f,90f));
        StartCoroutine(BeamP(-.4f,.5f, new Vector3(5f,0,0), 3.5f,-90f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.65f,.9f, new Vector3(20,20,0), .75f));
        StartCoroutine(Circle(.35f,.7f, new Vector3(20,20,0), .75f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.65f,.7f, new Vector3(20,20,0), .75f));
        StartCoroutine(Circle(.35f,.9f, new Vector3(20,20,0), .75f));
        yield return new WaitForSeconds(.46875f*.6f);
        StartCoroutine(Arrow(0,1, new Vector3(30,0,0),1, 90));
        StartCoroutine(Arrow(1,0, new Vector3(-30,0,0),1, -90));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(-30,0,0),1, -90));
        StartCoroutine(Arrow(0,0, new Vector3(30,0,0),1, 90));


    }
    public IEnumerator StartHard()
    {
    
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.5f, new Vector3(20,20,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        audio.StartAudio();
        
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*3f);
        StartCoroutine(Arrow(1,0, new Vector3(-30,0,0),.85f, -90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,.35f, new Vector3(-30,0,0),.85f, -90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(BeamR(.5f,1.8f, new Vector3(-1f,-4f,0), 3, 0f, .1f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Circle(.3f,.2f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.8f,.4f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.6f,.1f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.5f,.3f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(BeamR(.5f,-.8f, new Vector3(1f,4f,0), 3, 180f, .1f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Circle(.7f,.7f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.2f,.9f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.4f,.6f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.5f,.8f, new Vector3(11,11,0), .5f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(0,.5f, new Vector3(30,0,0),.9f, 90f));
        StartCoroutine(Arrow(1,.5f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*2.5f);
        StartCoroutine(Arrow(0,.94f, new Vector3(30,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,.07f, new Vector3(-30,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Circle(.5f,.5f, new Vector3(20,20,0), 1f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,0, new Vector3(0,30,0),1, 180f));
        StartCoroutine(Arrow(0,0, new Vector3(0,30,0),1, 180f));
        yield return new WaitForSeconds(.46875f*3.5f);
        StartCoroutine(Beam(-.4f,.5f, new Vector3(1.8f,0f,0), 8,1, 90f));
        StartCoroutine(Beam(1.4f,.5f, new Vector3(-1.8f,0f,0), 8,1, -90f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Circle(.5f,1f, new Vector3(15,15,0), 1f));
        StartCoroutine(Arrow(1,0, new Vector3(-30,0,0),1, -90f));
        StartCoroutine(Arrow(0,0, new Vector3(30,0,0),1, 90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.8f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.6f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Circle(.5f,.4f, new Vector3(15,15,0), 1f));
        yield return new WaitForSeconds(.46875f*9.5f);
        //End of intro
        StartCoroutine(Circle(.8f,.2f, new Vector3(20,20,0), 1.5f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.6f,.6f, new Vector3(8,8,0), .75f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.3f,.4f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.1f,.9f, new Vector3(8,8,0), .75f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.5f,.7f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.7f,.3f, new Vector3(8,8,0), .75f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.1f,.6f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.4f,.2f, new Vector3(8,8,0), .75f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.7f,.6f, new Vector3(20,20,0), 1.5f));
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(Circle(.2f,.8f, new Vector3(8,8,0), .75f));    
        yield return new WaitForSeconds(.46875f*.75f);
        StartCoroutine(BeamP(.5f,1.8f, new Vector3(0f,-3f,0), 15,0f));
        StartCoroutine(BeamP(.5f,-.8f, new Vector3(0f,3f,0), 15,180f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(0f,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(0f,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.757f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,.243f, new Vector3(-40,0,0),.9f, -90f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(0,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(0,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.205f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-40,0),.895f, 0f));
        StartCoroutine(Arrow(.795f,1, new Vector3(0,-40,0),.895f, 0f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(BeamPScaled(1f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(0f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f); 
        StartCoroutine(Arrow(0,1f, new Vector3(40,0,0),1f, 90f));
        StartCoroutine(Arrow(0,0f, new Vector3(40,0,0),1f, 90f));
        yield return new WaitForSeconds(.46875f*1f); 
        StartCoroutine(BeamPScaled(.345f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(.655f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1f, new Vector3(-40,0,0),1f, -90f));
        StartCoroutine(Arrow(1,0f, new Vector3(-40,0,0),1f, -90f));
        yield return new WaitForSeconds(.46875f*1f); 
        StartCoroutine(BeamPScaled(.5f,.75f, new Vector3(0f,0f,0),new Vector3(200,15,0), 2,0f));
        StartCoroutine(BeamPScaled(.5f,.25f, new Vector3(0f,0f,0),new Vector3(200,15,0), 2,0f));    
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-40,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-40,0),1, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.24f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        StartCoroutine(BeamPScaled(.76f,.5f, new Vector3(0f,0f,0),new Vector3(15,100,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,0, new Vector3(0,40,0),1, 180f));
        StartCoroutine(Arrow(0,0, new Vector3(0,40,0),1, 180f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Beam(-.4f,-.4f, new Vector3(1.5f,1.5f,0), 7,1, -45f));
        StartCoroutine(Beam(1.4f,1.4f, new Vector3(-1.5f,-1.5f,0), 7,1, -45f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Circle(.5f,.5f, new Vector3(25,25,0), 4f));
        StartCoroutine(Beam(-.4f,1.4f, new Vector3(3f,-3f,0), 3,1, 45f));
        StartCoroutine(Beam(1.4f,-.4f, new Vector3(-3f,3f,0), 3,1, 45f)); 
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(1,0, new Vector3(-30,20,0),1, 60f));
        StartCoroutine(Arrow(0,0, new Vector3(30,20,0),1, -60f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(0,1f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(0,.635f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Beam(.5f,-.8f, new Vector3(0,5f,0), 3,1, 180f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(Arrow(.3f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(.7f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(.1f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(.9f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(-.1f,1, new Vector3(0,-30,0),.88f, 0f));
        StartCoroutine(Arrow(1.1f,1, new Vector3(0,-30,0),.88f, 0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,1, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,.8f, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 2,0f));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(BeamPScaled(.5f,.6f, new Vector3(0f,0f,0),new Vector3(300,20.8f,0), 1.5f,0f));
        yield return new WaitForSeconds(.46875f*2f);
        StartCoroutine(Arrow(1,1, new Vector3(0,-30,0),1, 0f));
        StartCoroutine(Arrow(0,1, new Vector3(0,-30,0),1, 0f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(1,0, new Vector3(-30,20,0),1, 60f));
        StartCoroutine(Arrow(0,0, new Vector3(30,20,0),1, -60f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Arrow(0,0, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Arrow(0,.365f, new Vector3(30f,0,0),.9f, 90f));
        yield return new WaitForSeconds(.46875f*.5f);
        StartCoroutine(Beam(.5f,1.8f, new Vector3(0,-5f,0), 3,1, 0f));
        yield return new WaitForSeconds(.46875f*4f);
        StartCoroutine(BeamP(1.4f,.5f, new Vector3(-5f,0,0), 3.5f,90f));
        StartCoroutine(BeamP(-.4f,.5f, new Vector3(5f,0,0), 3.5f,-90f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.65f,.9f, new Vector3(20,20,0), .75f));
        StartCoroutine(Circle(.35f,.7f, new Vector3(20,20,0), .75f));
        yield return new WaitForSeconds(.46875f*1.5f);
        StartCoroutine(Circle(.65f,.7f, new Vector3(20,20,0), .75f));
        StartCoroutine(Circle(.35f,.9f, new Vector3(20,20,0), .75f));
        yield return new WaitForSeconds(.46875f*.6f);
        StartCoroutine(Arrow(0,1, new Vector3(30,0,0),1, 90));
        StartCoroutine(Arrow(1,0, new Vector3(-30,0,0),1, -90));
        yield return new WaitForSeconds(.46875f*1f);
        StartCoroutine(Arrow(1,1, new Vector3(-30,0,0),1, -90));
        StartCoroutine(Arrow(0,0, new Vector3(30,0,0),1, 90));
        
    }
    public void StartFull()
    {
        Debug.Log("Full");
    }
    
    public IEnumerator Arrow(float x,float y,Vector3 movement,float scale,float degrees)
    {
        
        float newY;
        float newX;
        
        Vector3 newAPscale = APscale;
        Vector3 newScale = new Vector3(40,20,1);
        Vector3 newGlowScale = new Vector3(3.2f,2.5f,1);
        
        newScale *= scale;
        
        newGlowScale *= scale;
        if(x < .5f){
                x+=.1f;
            }
            else if(x > .5f){
                x-=.1f;    
            }
       
        if(y < .5f){
                y+=.075f;
            }
            else if(y > .5f){
                y-=.075f;
            }
        if(degrees == 180 || degrees == 0){
            
            if(y < .5f){
                newY = .1f*scale;
            }
            else{
                newY = 1-.1f*scale;
            }

            GetSpace(x,newY);
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            Glow.AttackIndicator(p,newGlowScale,180 - degrees);
            
        }
        else if(degrees == 60 || degrees == -60)
        {
            if(x < .5f){
                newX = .1f*scale;
            }
            else{
                newX = 1-.1f*scale;
            }
            if(y < .5f){
                newY = .1f*scale;
            }
            else{
                newY = 1-.1f*scale;
            }
            
            GetSpace(newX,newY);
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            Glow.AttackIndicator(p,newGlowScale*2,degrees);
            degrees = 180+degrees;
        }
        else{
            
            if(x < .5f){
                newX = .08f*scale;
            }
            else{
                newX = 1-.08f*scale;
            }

            GetSpace(newX,y);
            movement*=newAPscale.x;
            newGlowScale.x *= newAPscale.y;
            newGlowScale.y *= newAPscale.x;
            newScale.x *= newAPscale.y;
            newScale.y *= newAPscale.x;
            
            Glow.AttackIndicator(p,newGlowScale,180 + degrees);
        }
        yield return new WaitForSeconds(.46875f*4f);
        GetSpace(x,y);  
        arrow = Instantiate(attack1, p,transform.rotation);
        arrow.transform.localScale = newScale;
        arrow.transform.Rotate(0,0,degrees);
        arrow.AddComponent<Rigidbody2D>().AddForce(movement, ForceMode2D.Impulse);
        arrow.GetComponent<Rigidbody2D>().gravityScale = 0;

        
    }
    public IEnumerator Beam(float x, float y,Vector3 movement,float changeDirection,float scale,float degrees)
    {
        float newX;
        float newY;
        Vector3 newAPscale = APscale;
        Vector3 newScale = new Vector3(300,100,1);
        Vector3 newGlowScale = new Vector3(20f,2.5f,1);
        newScale *= scale;
        newGlowScale *= scale;
        if(degrees == 180 || degrees == 0){
            if(movement.y>0){
                newY = .1f*scale;
            }
            else{
                newY = 1-.1f*scale;
            }
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            GetSpace(x,newY);
            Glow.AttackIndicator(p,newGlowScale,180 - degrees);
            
        }
        else if(degrees == -45 || degrees == 45)
        {
            movement*=newAPscale.x;
        }
        else{
            if(movement.x>0){
                newX = .08f*scale;
            }
            else{
                newX = 1-.08f*scale;
            }
            movement*=newAPscale.x;
            newGlowScale.x *= newAPscale.y;
            newGlowScale.y *= newAPscale.x;
            newScale.x *= newAPscale.y;
            newScale.y *= newAPscale.x;
            p.x /= newAPscale.y;
            p.y /= newAPscale.x;
            GetSpace(newX,y);
            Glow.AttackIndicator(p,newGlowScale,180 + degrees);
            
        }
        yield return new WaitForSeconds(.46875f*4f);
        GetSpace(x,y);
        beam = Instantiate(attack2,p, transform.rotation);
        beam.transform.Rotate(0,0,degrees);
        beam.transform.localScale = newScale;
        beam.AddComponent<Rigidbody2D>().AddForce(movement, ForceMode2D.Impulse);
        Rigidbody2D beamR = beam.GetComponent<Rigidbody2D>();
        beam.GetComponent<Rigidbody2D>().gravityScale = 0;
        if(changeDirection != 0)
        {
            yield return new WaitForSeconds(.46875f*changeDirection);
            beamR.AddForce(-movement*3, ForceMode2D.Impulse);
        }
        
    }
    public IEnumerator BeamR(float x, float y,Vector3 movement,float change,float degrees,float torque)
    {
        float newX;
        float newY;
        Vector3 newAPscale = APscale;
        Vector3 newScale = new Vector3(300,100,1);
        Vector3 newGlowScale = new Vector3(20f,2.5f,1);
        if(degrees == 180 || degrees == 0){
            if(movement.y > 0){
                newY = .1f;
            }
            else{
                newY = .9f;
            }
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            GetSpace(x,newY);
            Glow.AttackIndicator(p,newGlowScale,180 - degrees);
            
        }
        else{
            if(movement.x > 0){
                newX = .08f;
            }
            else{
                newX = .92f;
            }
            movement*=newAPscale.x;
            newGlowScale.x *= newAPscale.y;
            newGlowScale.y *= newAPscale.x;
            newScale.x *= newAPscale.y;
            newScale.y *= newAPscale.x;
            GetSpace(newX,y);
            Glow.AttackIndicator(p,newGlowScale,180 + degrees);
            
        }
        yield return new WaitForSeconds(.46875f*4f);
        GetSpace(x,y);
        beam = Instantiate(attack2,p, transform.rotation);
        beam.transform.localScale = newScale;
        beam.transform.Rotate(0,0,degrees);
        beam.AddComponent<Rigidbody2D>().AddForce(movement, ForceMode2D.Impulse);
        Rigidbody2D beamR = beam.GetComponent<Rigidbody2D>();
        beamR.AddTorque(torque, ForceMode2D.Impulse);
        beamR.gravityScale = 0;
        if(change != 0)
        {
            yield return new WaitForSeconds(.46875f*change);
            beamR.AddForce(-movement*3, ForceMode2D.Impulse);

        }

        
    }
    public IEnumerator BeamP(float x, float y,Vector3 movement,float pause,float degrees)
    {
        float newX;
        float newY;
        Vector3 newAPscale = APscale;
        Vector3 newScale = new Vector3(300,100,1);
        Vector3 newGlowScale = new Vector3(20f,2.5f,1);
        if(degrees == 180 || degrees == 0){
            if(movement.y > 0){
                newY = .1f;
            }
            else{
                newY = .9f;
            }
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            GetSpace(x,newY);
            Glow.AttackIndicator(p,newGlowScale,180 - degrees);
            
        }
        else{
            if(movement.x > 0){
                newX = .05f;
            }
            else{
                newX = .95f;
            }
            movement*=newAPscale.x;
            newGlowScale.x *= newAPscale.y;
            newGlowScale.y *= newAPscale.x;
            newScale.x *= newAPscale.y;
            newScale.y *= newAPscale.x;
            GetSpace(newX,y);
            Glow.AttackIndicator(p,newGlowScale,180 - degrees);
            
        }
        
        yield return new WaitForSeconds(.46875f*4f);
        GetSpace(x,y);
        beam = Instantiate(attack2,p, transform.rotation);
        beam.transform.Rotate(0,0,degrees);
        beam.transform.localScale = newScale;
        beam.AddComponent<Rigidbody2D>().AddForce(movement, ForceMode2D.Impulse);
        Rigidbody2D beamR = beam.GetComponent<Rigidbody2D>();
        beam.GetComponent<Rigidbody2D>().gravityScale = 0;
        yield return new WaitForSeconds(.46875f*2);
        beamR.AddForce(-movement, ForceMode2D.Impulse);
        yield return new WaitForSeconds(.46875f*pause);
        beamR.AddForce(-movement, ForceMode2D.Impulse);    
    }
    public IEnumerator BeamPScaled(float x,float y,Vector3 movement,Vector3 scale,float pause,float degrees)
    {
        Vector3 newAPscale = APscale;
        Vector3 newScale = scale;
        Vector3 newGlowScale = new Vector3(1.552f,2f,1);
        if(x < .5f){
                x+=.1f;
            }
            else if(x > .5f){
                x-=.1f;
            }
        if(y < .5f){
                y+=.075f;
            }
            else if(y > .5f){
                y-=.075f;
            }
        if(scale.x > scale.y) {
            newGlowScale.x *= newAPscale.y;
            newGlowScale.y *= newAPscale.x;
            newScale.x *= newAPscale.y;
            newScale.y *= newAPscale.x;
            
            GetSpace(.06f,y);
            Glow.AttackIndicator(p,newGlowScale,-90);
            GetSpace(.94f,y);
            Glow.AttackIndicator(p,newGlowScale,90);
            
        }
        else{
            movement*=newAPscale.x;
            newGlowScale.x *= newAPscale.x;
            newGlowScale.y *= newAPscale.y;
            newScale.x *= newAPscale.x;
            newScale.y *= newAPscale.y;
            
            GetSpace(x,.08f);
            Glow.AttackIndicator(p,newGlowScale,0);
            GetSpace(x,.92f);
            Glow.AttackIndicator(p,newGlowScale,180);
            
                
        }
        yield return new WaitForSeconds(.46875f*4f);
        GetSpace(x,y);
        
        beam = Instantiate(attack2,p, transform.rotation);
        beam.transform.localScale = newScale;
        beam.transform.Rotate(0,0,degrees);
        beam.AddComponent<Rigidbody2D>().AddForce(movement, ForceMode2D.Impulse);
        Rigidbody2D beamR = beam.GetComponent<Rigidbody2D>();
        beam.GetComponent<Rigidbody2D>().gravityScale = 0;
        yield return new WaitForSeconds(.46875f*pause);
        if(scale.x > scale.y) {
            beamR.AddForce(new Vector3(10000,0,0), ForceMode2D.Impulse);
        }
        else{
            beamR.AddForce(new Vector3(0,10000,0), ForceMode2D.Impulse);
        }
    }
    public IEnumerator Circle(float x, float y,Vector3 scale,float duration)
    {
        Vector3 newAPscale = APscale;
        scale.x *= newAPscale.x;
        scale.y *= newAPscale.y;
        GetSpace(x,y);
        Glow.CircleAttackIndicator(p,scale);
        yield return new WaitForSeconds(.46875f*4);
        GetSpace(x,y);
        circle = Instantiate(attack3, p, transform.rotation);
        Transform tran = circle.GetComponent<Transform>();
        tran.localScale = scale;
        yield return new WaitForSeconds(.46875f*duration); 
        tran.position = new Vector3(100,100,0);
    }

    */
}
