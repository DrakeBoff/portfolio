using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem.EnhancedTouch;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;
using TouchPhase = UnityEngine.InputSystem.TouchPhase;

public class player : MonoBehaviour
{
    public rotator Rotate;  
    public combat Combat;

    public bool rightTouch = false;
    public bool leftTouch = false;
    public float rotateSpeed;
    public float moveSpeed;
    private Vector3 previousPosition = new Vector3(0,0,0);
    public bool outside;
    public bool hitShip;
    public bool boxTouch = false;
    
    private Animator anim;

    private bool invincible = false;
    public int health;
    public string hp;

    private void Awake()
    {
        EnhancedTouchSupport.Enable();
        

    }
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        
    }

    // Update is called once per frame
    void Update()
    {
        hp = "HP " + health.ToString();
        previousPosition = transform.position;
        foreach(Finger eachFinger in Touch.activeFingers) 
        {
            Touch touch = eachFinger.currentTouch;
            
            if (touch.phase == TouchPhase.Began || touch.phase == TouchPhase.Moved)
            {
                
                if(touch.screenPosition.x < (Screen.width / 2f))
                {
                 leftTouch = true;
                }
                else if(touch.screenPosition.x >= (Screen.width / 2f))
                {
                rightTouch = true;
                }
                
                
            }
            else
            {
                rightTouch = false;
                leftTouch = false;
            }
            
            
        }
        transform.position = Vector3.MoveTowards(transform.position, Rotate.transform.position, moveSpeed/10 * Time.deltaTime);
        Rotate.transform.position += transform.position - previousPosition;
        //Delete when testing touch controls
        if(Input.GetKey(KeyCode.RightArrow))
        {
            rightTouch = true;
        }
        else
        {
            rightTouch = false;
        
        }
        if(Input.GetKey(KeyCode.LeftArrow))
        {
            leftTouch = true;
        }
        else
        {
            leftTouch = false;
        }
        //
        if(rightTouch)
        {
            transform.Rotate(new Vector3(0,0,-rotateSpeed * Time.deltaTime));
            Rotate.rotate(-rotateSpeed);
            
        }
        

        if(leftTouch)
        {
            transform.Rotate(new Vector3(0,0,rotateSpeed * Time.deltaTime));
            Rotate.rotate(rotateSpeed);
            
        }
        
        if(rightTouch && leftTouch)
        {
            
                transform.position = Vector3.MoveTowards(transform.position, Rotate.transform.position, moveSpeed * Time.deltaTime);
                Rotate.transform.position += transform.position - previousPosition;
            
            
            

            
        }
       
    }   
    
    public IEnumerator TakeDamage()
    {
        if(invincible){
        }
        else{
            health--;
            anim.SetBool("Invincible", true);
            invincible = true;
            yield return new WaitForSeconds(1);
            anim.SetBool("Invincible", false);
            invincible = false;
        }
        if(health <= 0){
            Combat.GameOver();
        }
        

    }

    
    void OnBecameInvisible()
    {
        if(transform.position.x > 10.4f || transform.position.x < -10.4f){
            outside = true;
            Combat.GameOver();
        }
        if(transform.position.y > 5.1f || transform.position.y < -5.1f){
            outside = true;
            Combat.GameOver();
        }
        
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if(other.gameObject.GetComponent<attack>() != null || other.gameObject.GetComponent<dontTouch>() != null)
        {
            StartCoroutine(TakeDamage());
        }
        if(other.gameObject.GetComponent<enemyShip>() != null)
        {
            hitShip = true;
            Combat.GameOver();
        }
        if(other.gameObject.GetComponent<dontTouch>() != null)
        {
            hitShip = true;
            Combat.GameOver();
        }
        
    }
       
}
