using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyShip : MonoBehaviour
{
    public Animator anim;
    public bool left;
    public bool right;
    public float beatsToWait;
    public Rigidbody2D rigid;
    private bool onScreen;

    
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        anim = gameObject.GetComponent<Animator>();
        StartCoroutine(ShipControlledMovement());
        StartCoroutine(ShipMovement());
    }

    public IEnumerator ShipControlledMovement()
    {
        if(right){
            anim.SetBool("EntR", true);
            yield return new WaitForSeconds(beatsToWait*StaticData.songBPS);
            anim.SetBool("EntR", false);
            anim.SetBool("ExR", true);
            onScreen = false;
        }
        if(left){
            anim.SetBool("EntL", true);
            yield return new WaitForSeconds(beatsToWait*StaticData.songBPS);
            anim.SetBool("EntL", false);
            anim.SetBool("ExL", true);
            onScreen = false;
        }
        
    }
    public IEnumerator ShipMovement()
    {
        
        for(int i =0;i<10;i++){
            rigid.AddForce(new Vector3(0,.1f,0), ForceMode2D.Impulse);
            yield return new WaitForSeconds(.1f);
        }
        while(onScreen){
            for(int i =0;i<10;i++){
                rigid.AddForce(new Vector3(0,-.2f,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.1f);
            }
            for(int i =0;i<10;i++){
                rigid.AddForce(new Vector3(0,.2f,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.1f);
            }
        }
        
    }

}
