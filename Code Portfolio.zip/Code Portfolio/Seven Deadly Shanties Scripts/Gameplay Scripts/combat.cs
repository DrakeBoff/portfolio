using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class combat : MonoBehaviour
{
    new public audioController audio;
    public camera Camera1;
    public completionPercent compPer;
    public UIcontroller UI;
    public gameOverText goText;
    public outOfBoundsText oobText;
    
    //bps = 1/(bpm/60)
    public float songBPS = .46875f;
    public bool songIsPlaying = true;

    private float toggle;
    private float APratio;
    private Vector3 APscale;
   
    Rigidbody2D rigid;
    private float diffX;
    private float diffY;

    Transform CanvasT;
    public GameObject Canvas;

    public bool gameOver;
    public GameObject[] EasySequence;
    public GameObject[] EasyIndicators;
    public GameObject[] FullSequence;
    public GameObject[] FullIndicators;

  
    
   
    // Start is called before the first frame update
    void Start()
    {
        
        APscale = new Vector3(1,1,1);
      
      diffX = StaticData.widthDiff;
      diffY = StaticData.heightDiff;
      
      APratio = StaticData.APtoggle;
      StartCombat();    
        
        
        
        Time.timeScale = 1;
        CanvasT = Canvas.GetComponent<Transform>();
        if(APratio == 1){
            APscale.x = .9f;
            APscale.y = 1;
        }
        else if(APratio == 2){
            APscale.x = .75f;
            APscale.y = 1;
        }
        
    }
    
    
    

    public void StartCombat()
    {

        
        string difficulty = StaticData.difficultyToggle;
        if(difficulty == "Easy") {
            StartCoroutine(StartEasy());
        }
        else if(difficulty == "Hard") {
            StartCoroutine(StartHard());
        }
        else if(difficulty == "Full") {
            StartCoroutine(StartFull());
        }

    }

    public void GameOver()
    {
        Debug.Log("Game Over");
        compPer.SetPercent();
        goText.GameOverPercent(false);
        oobText.OutofBounds();
        UI.ShowGameOver();

    }
    public void LevelCompleted()
    {
        Time.timeScale = 0;
        compPer.SetPercent();
        goText.GameOverPercent(true);
        UI.ShowGameOver();
        songIsPlaying = false;

    }

    public IEnumerator StartEasy()
    {
        yield return new WaitForSeconds(2);
        audio.StartAudio(); //Dont start without delay
        yield return new WaitForSeconds(.12f);
        int spawnIndex = 0;
        while(songIsPlaying)
        {
            
                yield return new WaitForSeconds(songBPS/StaticData.subdivisionOfBeat);   
                GameObject thingToSpawn = EasySequence[spawnIndex];
                GameObject indicatorToSpawn = EasyIndicators[spawnIndex];
                if(thingToSpawn != null)
                {
                    GameObject.Instantiate(thingToSpawn);
                }
                if(indicatorToSpawn != null)
                {
                    
                    GameObject.Instantiate(indicatorToSpawn);
                }
                spawnIndex++;
            
                
        }

    }  
    public IEnumerator StartHard()
    {
        yield return new WaitForSeconds(2);
        audio.StartAudio(); //Dont start without delay
        yield return new WaitForSeconds(.12f);
        int spawnIndex = 0;
        while(songIsPlaying&& spawnIndex <=320)
        {
            
                yield return new WaitForSeconds(songBPS/StaticData.subdivisionOfBeat);   
                GameObject thingToSpawn = FullSequence[spawnIndex];
                GameObject indicatorToSpawn = FullIndicators[spawnIndex];
                if(thingToSpawn != null)
                {
                    GameObject.Instantiate(thingToSpawn);
                }
                if(indicatorToSpawn != null)
                {
                    
                    GameObject.Instantiate(indicatorToSpawn);
                }
                spawnIndex++;
            
        }
    } 
    public IEnumerator StartFull()
    {
        
        yield return new WaitForSeconds(2);
        audio.StartAudio(); //Dont start without delay
        yield return new WaitForSeconds(.12f);
        int spawnIndex = 0;
        while(songIsPlaying)
        {
            
                yield return new WaitForSeconds(songBPS/StaticData.subdivisionOfBeat);   
                GameObject thingToSpawn = FullSequence[spawnIndex];
                GameObject indicatorToSpawn = FullIndicators[spawnIndex];
                if(thingToSpawn != null)
                {
                    GameObject.Instantiate(thingToSpawn);
                }
                if(indicatorToSpawn != null)
                {
                    
                    GameObject.Instantiate(indicatorToSpawn);
                }
                spawnIndex++;
            
                
        }
    } 
}
