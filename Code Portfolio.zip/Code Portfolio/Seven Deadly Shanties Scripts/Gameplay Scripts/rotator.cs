using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotator : MonoBehaviour
{
    
   
    public player Player;
    
    public GameObject ship;
    
    public bool touchBox;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
       
    
    }

    public void rotate(float rotateAmount)
    {
        if(Player.rightTouch == false || Player.leftTouch == false){
            transform.RotateAround(ship.transform.position, new Vector3(0,0,-0.2549996f+.3f), rotateAmount * Time.deltaTime);
        }
        
            
        
        
    }
    
}
