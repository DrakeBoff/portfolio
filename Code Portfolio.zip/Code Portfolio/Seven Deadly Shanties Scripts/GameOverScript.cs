using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverScript : MonoBehaviour
{
    AudioSource song;
    public GameObject audioObject;
    public GameObject GameOverPrefab;
    public Player player;
    



    // Start is called before the first frame update
    void Start()
    {

        song = GetComponent<AudioSource>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
        
    }

    public void endGame()
    {
        Instantiate(GameOverPrefab);
        player.StopPlayer();
        song.Stop();
        
    }
}
