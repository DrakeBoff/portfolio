using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deadly : MonoBehaviour
{

public GameObject lightning;
public GameOverScript gameover;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame 
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D other) 
    {
        if(other.gameObject.name == "Player") 
        {
            
            gameover.endGame();
        }

        if(other.gameObject.name == "CameraBoxBottom") 
        {
            Destroy(lightning);
        }
        
            
        

    }

     
}
