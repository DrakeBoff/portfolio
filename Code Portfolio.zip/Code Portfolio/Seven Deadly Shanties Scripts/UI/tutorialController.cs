using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tutorialController : MonoBehaviour
{
    public Animator animator;
    private float page;
    public singleAudio single;
    new public AudioSource audio;
    // Start is called before the first frame update
    void Start()
    {
        animator = gameObject.GetComponent<Animator>();   
    }

    // Update is called once per frame
    void Update()
    {
        page = StaticData.tutorialPage;
        animator.SetFloat("panel", page);
    }
    public void EnterTutorial()
    {
        animator.SetBool("inTutorial", true);
        audio = single.gameObject.GetComponent<AudioSource>();
        audio.volume = 1;
    }
    public void ExitTutorial()
    {
        animator.SetBool("inTutorial", false);
        StaticData.tutorialPage = 1;
    }

}
