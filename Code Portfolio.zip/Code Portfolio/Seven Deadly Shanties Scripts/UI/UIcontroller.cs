using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class UIcontroller : MonoBehaviour
{
    public Animator animator;
    new public audioController audio;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();

    }

    // Update is called once per frame
    public void ShowPause(){
        animator.SetBool("Pause Menu Showing", true);
        Time.timeScale = 0f;
        audio.PauseAudio();
    }
    public void HidePause(){
        animator.SetBool("Pause Menu Showing", false);
        Time.timeScale = 1f;
        audio.StartAudio();
    }
    public void ShowGameOver(){
        animator.SetBool("Game Over Menu Showing", true);
        Time.timeScale = 0f;
        audio.PauseAudio();
    }
    public void HideGameOver(){
        animator.SetBool("Game Over Menu Showing", false);
        Time.timeScale = 1f;
        audio.StartAudio();
    }
    public void ShowMenu(){
        animator.SetBool("Menu Showing", true);
        
    }
    public void HideMenu(){
        animator.SetBool("Menu Showing", false);
        
    }

}
