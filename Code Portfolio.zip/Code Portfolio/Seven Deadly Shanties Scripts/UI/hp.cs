using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class hp : MonoBehaviour
{
    public TMP_Text text;
    public player Player;
    

    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();

        
    }

    // Update is called once per frame
    void Update()
    {
        string newText = Player.hp;
        if(text.text != newText){
            text.text = newText;
        }
    }
}
