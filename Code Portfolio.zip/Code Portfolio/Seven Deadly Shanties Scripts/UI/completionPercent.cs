using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class completionPercent : MonoBehaviour
{
    public TMP_Text text;
    public progressBar progressbar;
    private float percent;
    public bool newBest;
    public saveManager SaveManager;

    // Start is called before the first frame update
    void Start()
    {
        
        text = GetComponent<TMP_Text>();
    }
    // Update is called once per frame
    void Update()
    {
        percent = progressbar.bar.value*100;
        percent = Mathf.Round(percent * 100.0f) / 100.0f;
        StaticData.percentText = percent.ToString()+"%";
        if(text.text != StaticData.percentText){
            text.text = StaticData.percentText;
        }
        
    }
    public void SetPercent(){
        if(percent > SaveManager.GetPercent(StaticData.level, StaticData.difficultyToggle)){
            StaticData.newPercentText = StaticData.percentText;
            StaticData.highestPercent = percent; 
            SaveManager.SaveGame();
            
            newBest = true;
        }  
    }
   
}
