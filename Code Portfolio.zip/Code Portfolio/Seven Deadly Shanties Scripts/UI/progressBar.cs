using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class progressBar : MonoBehaviour
{
    new public audioController audio;
    public Slider bar;
    public combat Combat;
    // Start is called before the first frame update
    void Start()
    {
        bar = gameObject.GetComponent<Slider>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if((audio.audioProgress / audio.audioLength) >= .001){
            bar.value = (audio.audioProgress / audio.audioLength);
        }
        if(bar.value == 1)
        {
            Combat.LevelCompleted();
        }
    }
}
