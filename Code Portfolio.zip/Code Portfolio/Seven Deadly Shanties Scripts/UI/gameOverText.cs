using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class gameOverText : MonoBehaviour
{
    public TMP_Text text;
    public completionPercent compPer;
    
    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
     
    public void GameOverPercent(bool completed){
        if(completed == false)
        {
            text.text = "Game Over";
        
            
        }
        else if(completed == true)
        {
            text.text = "Level Completed";
        }
        if (compPer.newBest){
            text.text += " New Best " + StaticData.newPercentText;
            compPer.newBest = false;
        }
        else
        {
            text.text += " "+StaticData.percentText;
        }
    }
   
}
