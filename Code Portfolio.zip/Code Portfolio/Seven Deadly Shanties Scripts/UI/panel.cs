using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class panel : MonoBehaviour
{
    public RectTransform rect;
    public RectTransform canvasRect;
    Vector2 screenSize;
    public Canvas canvas;
    // Start is called before the first frame update
    void Start()
    {
        canvasRect = canvas.gameObject.GetComponent<RectTransform>();
        rect = gameObject.GetComponent<RectTransform>();
        rect.sizeDelta = canvasRect.sizeDelta;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
