using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class difficultyDisplay : MonoBehaviour
{
    public TMP_Text difficulty;
    
    // Start is called before the first frame update
    void Start()
    {
        difficulty = GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
            difficulty.text = StaticData.difficultyToggle;
        
    }
    
}
