using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class outOfBoundsText : MonoBehaviour
{
    public TMP_Text text;
    public player Player;
    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
       
    }
    public void OutofBounds(){
        if(Player.outside == true){
            text.text = "Beware Exploring the Unknown";
        }
        else if(Player.hitShip == true)
        {
            text.text = "Your Ship was Destroyed";
        }
        else{
            text.text = "";
        }
    }

}
