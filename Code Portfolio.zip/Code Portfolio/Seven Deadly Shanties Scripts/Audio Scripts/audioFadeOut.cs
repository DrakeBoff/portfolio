using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class audioFadeOut : MonoBehaviour
{
    public singleAudio menu;
    new public AudioSource audio;

    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
            audio = menu.gameObject.GetComponent<AudioSource>();
        
        
    }
    public void FadeOut()
    {
        if(audio.volume > 0)
        {
            for(double i=0;i<1;i+=.001){
                //audio.volume -= .001f;
            }
            
        }
        
    }
    
}
