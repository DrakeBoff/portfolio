using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class singleAudio : MonoBehaviour
{
   new public AudioSource audio;

public AudioClip single;

void Start()
{
    audio = gameObject.AddComponent<AudioSource>();
    audio.loop = true;
    audio.clip = single;
    
    audio.Play();
    
}

}


