using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class audioController : MonoBehaviour
{
    new public AudioSource audio;
    public AudioClip Easy;
    public AudioClip Hard;
    public AudioClip Full;
    private string toggle;
    
    
    
    public float audioLength;
    public float audioProgress;
    
    // Start is called before the first frame update
    void Start()
    {
        audio = gameObject.AddComponent<AudioSource>();
        toggle = StaticData.difficultyToggle;
        if(toggle == "Easy")
        {
            audio.clip = Easy;
        }
        if(toggle == "Hard")
        {
            audio.clip = Hard;
        }
        if(toggle == "Full")
        {
            audio.clip = Full;
        }

        
        
        audio.loop = false;
        //audio.time = 29;
    }

    // Update is called once per frame
    void Update()
    {
        audioProgress = audio.time;
        audioLength = audio.clip.length - 2;
        


        
    }
    public void StartAudio()
    {
        
        audio.Play(0);
    }
    public void PauseAudio()
    {
        audio.Pause();
    }
    
    public void SetCompound()
    {
        StaticData.subdivisionOfBeat = 3;
    }
    public void SetSimple()
    {
        StaticData.subdivisionOfBeat = 2;
    }
}
