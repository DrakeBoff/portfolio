using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class glowcontroller : MonoBehaviour
{
    public Animator animate;
    private GameObject Glow;
    private GameObject Circle;
    public GameObject glow1;
    public GameObject glow2;

    Transform CanvasT;
    public GameObject Canvas;

    // Start is called before the first frame update
    void Start()
    {
        CanvasT = Canvas.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void AttackIndicator(Vector3 pos, Vector3 scale, float degrees)
    {
        
        
        Glow = Instantiate(glow1,pos, transform.rotation);
        Glow.transform.localScale = scale;
        Glow.transform.Rotate(0,0,degrees);
        Glow = Instantiate(glow1,pos, transform.rotation);
        Glow.transform.localScale = scale;
        Glow.transform.Rotate(0,0,degrees);
    }
    public void CircleAttackIndicator(Vector3 pos, Vector3 scale)
    {
        Circle = Instantiate(glow2,pos, transform.rotation);
        Circle.transform.localScale = scale / 6;
        Circle = Instantiate(glow2,pos, transform.rotation);
        Circle.transform.localScale = scale / 6;
    }
}
