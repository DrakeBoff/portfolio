using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private bool left = true;
    private bool right = true;
    private bool up = true;
    private bool down = true;

    private bool leftPressed = false;
    private bool rightPressed = false;
    private bool upPressed = false;
    private bool downPressed = false;


    public float moveSpeed = 10;


    public bool isAlive = true;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    //Player movements that can be used by arrows or WASD
    if(isAlive == true)
    {
        if(Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)){
            upPressed = true;
        }
        else{
            upPressed = false;
        }

        if(Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)){
            downPressed = true;
        }
        else{
            downPressed = false;
        }

        if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)){
            leftPressed = true;
        }
        else{
            leftPressed = false;
        }

        if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)){
            rightPressed = true;
        }
        else{
            rightPressed = false;
        }
       
    }
    else
    {
        upPressed = false;
        downPressed = false;
        rightPressed = false;
        leftPressed = false;

    }
        
    }


    void FixedUpdate()
    {

    //Movement but prevents going more than one direction at a time

        if(up == true) 
        {
            if(upPressed)
            {
                GetComponent<Rigidbody2D>().AddForce(new Vector3(0,moveSpeed,0), ForceMode2D.Impulse);
                down = false;
                left = false;
                right = false;
            }
            else
            {
                down = true;
                left = true;
                right = true;
            }

        }

        if(down == true) 
        {
            if(downPressed)
            {
                GetComponent<Rigidbody2D>().AddForce(new Vector3(0,-moveSpeed,0), ForceMode2D.Impulse);
                up = false;
                left = false;
                right = false;
            }
            else
            {
                up = true;
                left = true;
                right = true;
            }

        }

        if(right == true) 
        {
            if(rightPressed)
            {
                GetComponent<Rigidbody2D>().AddForce(new Vector3(moveSpeed,0,0), ForceMode2D.Impulse);
                down = false;
                left = false;
                up = false;
            }
            else
            {
                down = true;
                left = true;
                up = true;
            }

        }

        if(left == true) 
        {
            if(leftPressed)
            {
                GetComponent<Rigidbody2D>().AddForce(new Vector3(-moveSpeed,0,0), ForceMode2D.Impulse);
                down = false;
                up = false;
                right = false;
            }
            else
            {
                down = true;
                up = true;
                right = true;
            }

        }

       

    }
    public void StopPlayer()
    {
        Debug.Log("The Game is Over");
        isAlive = false;
        
    }
    
    public bool Alive()
    {
        return isAlive;
    }
}
