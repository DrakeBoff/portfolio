using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tutorialButtons : MonoBehaviour
{
    public bool forwardButton;
    public bool backwardButton;
    public bool exitButton;
    private float page;
    private RectTransform rect;
    // Start is called before the first frame update
    void Start()
    {
        if(exitButton){
            rect = gameObject.GetComponent<RectTransform>();
            MoveExitButton();
        }
        
        
    }

    // Update is called once per frame
    void Update()
    {
        page = StaticData.tutorialPage;
        if(exitButton)
        {
        if(StaticData.tutorialCompleted == true)
                    {
                        rect.anchoredPosition = new Vector2(-60,-40);
                    }
        }
        
        
        
        
    }
    public void ButtonPressed()
    {
        if(forwardButton)
        {
            if(page != 6)
            {
                StaticData.tutorialPage++;
            }
            else
            {
                StaticData.tutorialPage = 1;
            }
        }
        else if(backwardButton)
        {
            if(page != 1)
            {
                StaticData.tutorialPage--;
            }
            else
            {
                StaticData.tutorialPage = 6;
            }
        }
        
    }
    private IEnumerator MoveExitButton()
    {
        yield return new WaitForSeconds(1/59);
                Debug.Log("Moving exitButton");
                rect.anchoredPosition += new Vector2(1000,0);
    }
}
