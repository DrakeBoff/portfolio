using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class difficultyManager : MonoBehaviour
{
    
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void ToggleDifficulty()
    {
        if(StaticData.difficultyToggle == "Easy") {
            StaticData.difficultyToggle = "Hard";
        }
        else if(StaticData.difficultyToggle == "Hard") {
            StaticData.difficultyToggle = "Full";
        }
        else if(StaticData.difficultyToggle == "Full") {
            StaticData.difficultyToggle = "Easy";
        }
    }
}
