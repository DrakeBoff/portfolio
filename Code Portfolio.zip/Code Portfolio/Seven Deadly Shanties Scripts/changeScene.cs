using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class startGame : MonoBehaviour
{
    public string levelName;
    public tutorialController tutorial;
    public bool firstPlayButton;
    // Start is called before the first frame update
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void StartLevel()
    {
        if(firstPlayButton)
        {
            if(StaticData.tutorialCompleted)
            {
                SceneManager.LoadScene(levelName);
            }
            else
            {
                tutorial.EnterTutorial();
            }
        }
        else
            {
                SceneManager.LoadScene(levelName);
            }
        
    }
    

}
