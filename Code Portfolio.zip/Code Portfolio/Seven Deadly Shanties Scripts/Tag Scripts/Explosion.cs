using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    private SpriteRenderer sprite;
    private Color alpha;
    new private CircleCollider2D collider;
    // Start is called before the first frame update
    void Start()
    {
        sprite = gameObject.GetComponent<SpriteRenderer>();
        collider = gameObject.GetComponent<CircleCollider2D>();
        alpha = sprite.color;
        StartCoroutine(FadeAway());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator FadeAway()
    {
        alpha.a = 1;
        yield return new WaitForSeconds(StaticData.songBPS*2);
        for(int i=0;i<50;i++){
            yield return new WaitForSeconds(.01f);
            alpha.a -= .02f;
            sprite.color = alpha;
            if(i == 20){
                collider.isTrigger = false;
            }
        }
        Destroy(gameObject);
    }
}
