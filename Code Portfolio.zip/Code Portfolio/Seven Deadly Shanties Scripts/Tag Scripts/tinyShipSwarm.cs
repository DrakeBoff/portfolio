using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tinyShipSwarm : MonoBehaviour
{
    Rigidbody2D rigid;
    bool onScreen = true;
    public float duration;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        StartCoroutine(Entrance());
        if(duration == 0)
        {
            duration = 18;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    IEnumerator Entrance()
    {
        rigid.AddForce(new Vector3(0,-3,0), ForceMode2D.Impulse);
        for(int i=0;i<10;i++)
        {
            rigid.AddForce(new Vector3(0,.3f,0), ForceMode2D.Impulse);
            yield return new WaitForSeconds(.3f);
        }
        StartCoroutine(ShipMovement());
        yield return new WaitForSeconds(duration);
        Exit();
        yield return new WaitForSeconds(10);
        onScreen = false;
        
    }
    IEnumerator ShipMovement()
    {
        yield return new WaitForSeconds(Random.Range(0,.7f));
        for(int i =0;i<10;i++){
            rigid.AddForce(new Vector3(0,.1f,0), ForceMode2D.Impulse);
            yield return new WaitForSeconds(.1f);
        }
        while(onScreen){
            for(int i =0;i<10;i++){
                rigid.AddForce(new Vector3(0,-.2f,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.1f);
            }
            for(int i =0;i<10;i++){
                rigid.AddForce(new Vector3(0,.2f,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.1f);
            }
        }
    }
    void Exit()
    {
        rigid.AddForce(new Vector3(0,2,0), ForceMode2D.Impulse);
    }
}
