using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attackIndicator : MonoBehaviour
{
    public float duration;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Duration());
    }
    private IEnumerator Duration()
    {
        yield return new WaitForSeconds(StaticData.songBPS*duration);
        Destroy(gameObject);
    }
}
