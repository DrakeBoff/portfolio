using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class glow : MonoBehaviour
{

    public bool circleGlow;
    
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(DestroyIndicator());
        
    }

    private IEnumerator DestroyIndicator()
    {
        if(circleGlow){
            yield return new WaitForSeconds(StaticData.subdivisionOfBeat/2);
        }
        else{
            yield return new WaitForSeconds(StaticData.subdivisionOfBeat*2);
        }
        
        Destroy(gameObject);
    }
    
    
}
