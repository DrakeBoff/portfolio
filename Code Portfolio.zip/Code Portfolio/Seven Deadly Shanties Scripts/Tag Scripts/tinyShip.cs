using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tinyShip : MonoBehaviour
{
    Rigidbody2D rigid;
    public float cannonAttackSpeed;
    public float minesAttackSpeed;
    public GameObject mine;
    public GameObject mineGlow;
    public GameObject explosion;
    public GameObject cannonGlow;
    public GameObject cannonBall;
    private bool onScreen = true;

    private Vector3 currentPosition;
    // Start is called before the first frame update
    void Start()
    {
        currentPosition = gameObject.transform.position;
        rigid = gameObject.GetComponent<Rigidbody2D>();
        StartCoroutine(CannonAttack());
        StartCoroutine(MineAttack());
    }

    // Update is called once per frame
    void Update()
    {
       currentPosition = gameObject.transform.position;
    }
    private IEnumerator MineAttack()
    {
        rigid.AddForce(new Vector3(0,-3,0),ForceMode2D.Impulse);
        if(minesAttackSpeed != 0){
            while(onScreen)
            {
                GameObject.Instantiate(mine,currentPosition, transform.rotation);
                GameObject.Instantiate(mineGlow,currentPosition, transform.rotation);
                StartCoroutine(Explosion(currentPosition));
                yield return new WaitForSeconds(1/minesAttackSpeed);
            }

        } 
    }
    private IEnumerator CannonAttack()
    {
        if(cannonAttackSpeed != 0){
        while(onScreen)
            {
                Debug.Log("attack");
                GameObject.Instantiate(cannonGlow,currentPosition + new Vector3(0,.3f,0), transform.rotation);
                yield return new WaitForSeconds(.5f/cannonAttackSpeed);
                GameObject.Instantiate(cannonBall,currentPosition, transform.rotation);
                yield return new WaitForSeconds(.5f/cannonAttackSpeed);
            }
        }
    }
    void OnBecameInvisible()
    {
        onScreen = false;
    }
    private IEnumerator Explosion(Vector3 position)
    {
        yield return new WaitForSeconds(StaticData.songBPS*2);
        GameObject.Instantiate(explosion,position, transform.rotation);
    }
}
