using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bigCoin : MonoBehaviour
{
     
    public float velocity;
    public float duration;
    private Rigidbody2D rigid;
    public GameObject glow;
    private float newVelocity;
    private float one;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        one = 1;
        newVelocity = velocity;
        StartCoroutine(Entrance());
    }

    public IEnumerator Entrance()
    {
        
        Instantiate(glow,transform.position + new Vector3(0,5,0),Quaternion.identity);
        yield return new WaitForSeconds((StaticData.songBPS/StaticData.subdivisionOfBeat)*2);
            rigid.AddForce(new Vector3(0,-newVelocity,0), ForceMode2D.Impulse);
            for(int i = 0;i<velocity;i++){
                rigid.AddForce(new Vector3(0,one,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        
        yield return new WaitForSeconds(duration);
        newVelocity *= -.5f;
        one= -1;
        StartCoroutine(Entrance());
        
        
    }
    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
