using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attack : MonoBehaviour
{
    
    Rigidbody2D rigid;
    public float xVelocity;
    public float yVelocity;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        rigid.AddForce(new Vector3(xVelocity,yVelocity,0),ForceMode2D.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.x>30 || transform.position.x<-30){
            Destroy(gameObject);
        }
        if(transform.position.y>30 || transform.position.y<-30){
            Destroy(gameObject);
        }
    }
    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    
}
