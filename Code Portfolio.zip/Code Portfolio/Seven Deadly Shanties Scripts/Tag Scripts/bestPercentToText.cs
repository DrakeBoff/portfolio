using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class bestPercentToText : MonoBehaviour
{
    public TMP_Text text;
    public saveManager SaveManager;
    public string Level;
    public string Difficulty;
    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();
    }

    // Update is called once per frame
    void Update()
    {
        text.text = Difficulty + " " + SaveManager.GetPercent(Level, Difficulty).ToString() + "%";
    }
}
