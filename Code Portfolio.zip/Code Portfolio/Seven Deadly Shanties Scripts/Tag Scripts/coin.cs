using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coin : MonoBehaviour
{
    public Rigidbody2D rigid;
    public float xVelocity;
    public float yVelocity;
    public string direction;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        if(direction == "left")
        {
            rigid.AddForce(new Vector3(xVelocity,yVelocity,0), ForceMode2D.Impulse);
        }
        else if(direction == "right")
        {
            rigid.AddForce(new Vector3(-xVelocity,yVelocity,0), ForceMode2D.Impulse);
        }
        else if(direction == "up")
        {
            rigid.AddForce(new Vector3(yVelocity,-xVelocity,0), ForceMode2D.Impulse);
        }
        else if(direction == "down")
        {
            rigid.AddForce(new Vector3(yVelocity,xVelocity,0), ForceMode2D.Impulse);
        }
        
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
