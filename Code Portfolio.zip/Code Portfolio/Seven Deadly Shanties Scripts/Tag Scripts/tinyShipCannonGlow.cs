using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tinyShipCannonGlow : MonoBehaviour
{
    Rigidbody2D rigid;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        rigid.AddForce(new Vector3(0,-3,0),ForceMode2D.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
