using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class treasureChest : MonoBehaviour
{
    public GameObject coin;
    public GameObject indicator;
    public string enterFrom;
    public float velocity;
    private float one;
    private float newVelocity;
    private Rigidbody2D rigid;
    public float duration;
    private bool done;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        newVelocity = velocity;
        one = 1;
        StartCoroutine(Entrance());
    }

    // Update is called once per frame
    void Update()
    {
    }
    public IEnumerator SpawnCoins()
    {
        Instantiate(indicator, transform.position, transform.rotation);
        yield return new WaitForSeconds((StaticData.songBPS/StaticData.subdivisionOfBeat)*2);
        Instantiate(coin, transform.position,transform.rotation);
        yield return new WaitForSeconds((StaticData.songBPS/StaticData.subdivisionOfBeat)*duration);
        newVelocity = -velocity;
        one = -1;
        done = true;
        StartCoroutine(Entrance());
        
        
    }
    public IEnumerator Entrance()
    {
        if(enterFrom == "left"){
            rigid.AddForce(new Vector3(newVelocity,0,0), ForceMode2D.Impulse);
            for(int i = 0;i<velocity;i++){
                rigid.AddForce(new Vector3(-one,0,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        }
        if(enterFrom == "right"){
            rigid.AddForce(new Vector3(-newVelocity,0,0), ForceMode2D.Impulse);
            for(int i = 0;i<velocity;i++){
                rigid.AddForce(new Vector3(one,0,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        }
        if(enterFrom == "top"){
            rigid.AddForce(new Vector3(0,-newVelocity,0), ForceMode2D.Impulse);
            for(int i = 0;i<velocity;i++){
                rigid.AddForce(new Vector3(0,one,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        }
        if(enterFrom == "bottom"){
            rigid.AddForce(new Vector3(0,newVelocity,0), ForceMode2D.Impulse);
            for(int i = 0;i<velocity;i++){
                rigid.AddForce(new Vector3(0,-one,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        }
        yield return new WaitForSeconds(.05f);
        if(done == false)
        {
            StartCoroutine(SpawnCoins());
        }
        
    }
    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
