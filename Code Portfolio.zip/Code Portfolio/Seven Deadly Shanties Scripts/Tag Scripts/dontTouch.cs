using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dontTouch : MonoBehaviour
{
   void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
    public void ManualDestroy()
    {
        Destroy(gameObject);
    }
}
