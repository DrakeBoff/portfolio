using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class water : MonoBehaviour
{
    bool i = true;
    private float random;
    // Start is called before the first frame update
    void Start()
    {
        random = Random.Range(-.7f,.7f);
        gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector3(random,-.2f,0), ForceMode2D.Impulse);
        gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
        StartCoroutine(WaterMovement());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private IEnumerator WaterMovement()
    {
        while(i){
            Rigidbody2D rigid = gameObject.GetComponent<Rigidbody2D>();
            
            for(int i = 0; i<Random.Range(20,30); i++){
                yield return new WaitForSeconds(.1f);
                rigid.AddForce(new Vector3(-random/10,0f,0), ForceMode2D.Impulse);
            }
            for(int i = 0; i<Random.Range(20,30); i++){
                yield return new WaitForSeconds(.1f);
                rigid.AddForce(new Vector3(random/10,0f,0), ForceMode2D.Impulse);
            }
            
        }
        
        
    }
    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

}
