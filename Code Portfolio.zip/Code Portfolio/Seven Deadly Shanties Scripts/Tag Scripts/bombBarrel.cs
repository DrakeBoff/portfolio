using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bombBarrel : MonoBehaviour
{
    Rigidbody2D rigid;
    public bool left;
    public bool right;
    public bool newBarrel;
    public float duration;
    public GameObject explosion;
    public GameObject glow;
    GameObject indicator;
    // Start is called before the first frame update
    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        rigid.AddForce(new Vector3(0,-.2f,0), ForceMode2D.Impulse);
        if(left){
            rigid.AddForce(new Vector3(22,0,0), ForceMode2D.Impulse);

        }
        if(right){
            rigid.AddForce(new Vector3(-22,0,0), ForceMode2D.Impulse);
        }
        if(newBarrel)
        {
            indicator = GameObject.Instantiate(glow,transform.position,Quaternion.identity);
        }
        StartCoroutine(SlowDown());
        StartCoroutine(Explosion());
    }

    // Update is called once per frame
    void Update()
    {
        if(newBarrel)
        {
            indicator.transform.position = gameObject.transform.position;
        }
        
    }
    private IEnumerator SlowDown()
    {
        if(left){
            for(int i = 0;i<22;i++){
                rigid.AddForce(new Vector3(-1,0,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
            

        }
        if(right){
            for(int i = 0;i<22;i++){
                rigid.AddForce(new Vector3(1,0,0), ForceMode2D.Impulse);
                yield return new WaitForSeconds(.05f);
            }
        }
    }
    private IEnumerator Explosion()
    {
        yield return new WaitForSeconds(StaticData.songBPS*duration);
        if(newBarrel){
            Instantiate(explosion, transform.position,Quaternion.identity);     
        }
        Destroy(gameObject);
    }
}
