using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightningSpawner : MonoBehaviour
{
    public Player player;
    public GameObject lightning;
    Vector3 spawnLocation;
    Vector3 spawnLocation2;
    Vector3 spawnLocation3;

    private float spawn;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnLightning());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    

    private IEnumerator SpawnLightning()
    {
        yield return new WaitForSeconds(3.1f);
        Randomize();
        while (player.Alive() == true)
        {
            
            yield return new WaitForSeconds(1);
            RandomSpawn();
            Randomize();
            yield return new WaitForSeconds(.5f);
            RandomSpawn();
            Randomize();
            yield return new WaitForSeconds(.5f);
            RandomSpawn();
            Randomize();

        }
        
        
    }

    private void Randomize()
    {
     
        

        spawnLocation = new Vector3(Random.Range(-40,-13.33f),17,0);
        spawnLocation2 = new Vector3(Random.Range(-13.33f,13.33f),17,0);
        spawnLocation3 = new Vector3(Random.Range(13.33f,40),17,0);
    }
    private void RandomSpawn()
    {
        spawn = Random.Range(1,15);
        if (spawn<1.3f)
        {
           Instantiate(lightning, spawnLocation, Quaternion.identity);
        }
        else if(spawn<1.7f)
        {
            Instantiate(lightning, spawnLocation2, Quaternion.identity);
        }
        else if(spawn<2)
        {
            Instantiate(lightning, spawnLocation3, Quaternion.identity);
        }
        else if(spawn<4)
        {
            Instantiate(lightning, spawnLocation, Quaternion.identity);
            Instantiate(lightning, spawnLocation2, Quaternion.identity);
        }
        else if(spawn<6)
        {
            Instantiate(lightning, spawnLocation, Quaternion.identity);
            Instantiate(lightning, spawnLocation3, Quaternion.identity);
        }
        else if(spawn<8)
        {
            Instantiate(lightning, spawnLocation2, Quaternion.identity);
            Instantiate(lightning, spawnLocation3, Quaternion.identity);
        }
        else
        {
            Instantiate(lightning, spawnLocation, Quaternion.identity);
            Instantiate(lightning, spawnLocation2, Quaternion.identity);
            Instantiate(lightning, spawnLocation3, Quaternion.identity);
        }
        
    }

}
