using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

public class saveManager : MonoBehaviour
{
    private gameData currentData;
    public bool saveGame;
    public bool saveTutorial;
    private string filepath;

    // Start is called before the first frame update
    void Awake()
    {
        
        currentData = new gameData();
        filepath = Path.Combine(Application.persistentDataPath, "TheSevenDeadlyShanties.json");
        try
        {
            using (StreamReader reader = new StreamReader(filepath))
            {
                string dataToLoad = reader.ReadToEnd();
                currentData =  JsonUtility.FromJson<gameData>(dataToLoad);
            }   
        }
        catch(Exception e)
        {
            Debug.Log("ERROR");
            currentData = new gameData();
        }
        
    }
    void Start()
    {
        
        StaticData.highestPercent = GetPercent(StaticData.level, StaticData.difficultyToggle);
        StaticData.tutorialCompleted = GetTutorial();
    }


    // Update is called once per frame
    void Update()
    {      
        if(saveTutorial){
            SaveTutorial();
            saveTutorial = false;
        } 
        if(saveGame){
            SaveGame();
            saveGame = false;
        }
    }
    public void SaveGame()
    {
        Debug.Log("Saved Data to "+filepath);
        if(StaticData.level == "Set Sail")
        {
            if(StaticData.difficultyToggle == "Easy")
            {
                currentData.SetSailPercentE = StaticData.highestPercent;
            }
            else if(StaticData.difficultyToggle == "Hard")
            {
                currentData.SetSailPercentH = StaticData.highestPercent;
            }
            else if(StaticData.difficultyToggle == "Full")
            {
                currentData.SetSailPercentF = StaticData.highestPercent;
            }
        }
        try
        {
            string dataString = JsonUtility.ToJson(currentData);
            using(StreamWriter writer = new StreamWriter(filepath))
            {
                writer.Write(dataString);
            }
        }
         catch(Exception e)
        {
            Debug.Log("ERROR");
        }
        
        Debug.Log(GetPercent("Set Sail","Easy"));
    }
    public void SaveTutorial()
    {
        currentData.tutorialCompleted = 1;
        StaticData.tutorialCompleted = true;
        try
        {
            string dataString = JsonUtility.ToJson(currentData);
            using(StreamWriter writer = new StreamWriter(filepath))
            {
                writer.Write(dataString);
            }
        }
         catch(Exception e)
        {
            Debug.Log("ERROR");
        }
        
        Debug.Log(GetPercent("Set Sail","Easy"));
    }
    public float GetPercent(string Level, string Difficulty)
    {
        if(Level == "Set Sail")
        {
            if(Difficulty == "Easy")
            {
                return currentData.SetSailPercentE;
            }
            else if(Difficulty == "Hard")
            {
                return currentData.SetSailPercentH;
            }
            else if(Difficulty == "Full")
            {
                return currentData.SetSailPercentF;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
        
    }
    public bool GetTutorial()
    {
        if(currentData.tutorialCompleted == 1){
        return true;
        }
        else
        {
            return false;
        }
    }

}

[System.Serializable]
public class gameData 
{
    public float SetSailPercentE = 0;
    public float SetSailPercentH = 0;
    public float SetSailPercentF = 0;
    public float tutorialCompleted = 0;

    
    
}