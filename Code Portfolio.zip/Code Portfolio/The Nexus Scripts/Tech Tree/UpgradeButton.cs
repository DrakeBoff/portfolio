using UnityEngine;
using System.Collections.Generic;

public class UpgradeButton : MonoBehaviour
{
    public int resource;
    public float cost;
    public string costSfx;
    
    public UnitSO[] unitsBeingChanged;
    public string variableBeingChanged;
    public float amountChanged;

    public float currentResourceAmt;
    public string currentSfx;

    public Canvas canvas;
    public GameObject[] spawnAfterPurchase;
    public ResourceManager resourceManager;

    public UnitSO[] arrayOfAllUnits;
    void Start()
    {
        GameObject manager = GameObject.Find("Resource Manager");
        resourceManager = manager.GetComponent<ResourceManager>();
        canvas = GetComponentInChildren<Canvas>();
    }

    void Update()
    {
        if(resource == 1)
        {
            currentResourceAmt = StaticData.resourceOneAmount;
            currentSfx = StaticData.resourceOneSuffix;
        }
    }

    //Triggers when the player has enough of a resource to buy an upgrade
    void BuyUpgrade()
    {
        resourceManager.ChangeResourceAmount(-cost, costSfx, resource);
        for(int i=0;i<spawnAfterPurchase.Length;i++)
        {
            Instantiate(spawnAfterPurchase[i]);
            StaticData.techTreeToSpawn.Add(spawnAfterPurchase[i]);
        }
        StaticData.techTreeToSpawn.Remove(gameObject);
        ApplyUpgrade();
        Destroy(gameObject);
    }
    
    //Helper method for BuyUpgrade() that will apply any of the effects I have created so far
    void ApplyUpgrade()
    {
        for(int i=0;i<unitsBeingChanged.Length;i++)
        {
            if(variableBeingChanged == "damage")
            {
                unitsBeingChanged[i].damage += amountChanged;
            }
            if(variableBeingChanged == "attackSpeed")
            {
                unitsBeingChanged[i].attackSpeed += amountChanged;
            }
            if(variableBeingChanged == "health")
            {
                unitsBeingChanged[i].health += amountChanged;
            }
            if(variableBeingChanged == "moveSpeed")
            {
                unitsBeingChanged[i].moveSpeed += amountChanged;
            }
            if(variableBeingChanged == "range")
            {
                unitsBeingChanged[i].range += amountChanged;
            }
            if(variableBeingChanged == "resourcesDropped")
            {
                unitsBeingChanged[i].resourcesDropped[0] += amountChanged;
            }
            if(variableBeingChanged == "amountOfUnit")
            {
                if(unitsBeingChanged[i] == arrayOfAllUnits[1])
                {
                    StaticData.numberOfSwordsman += (int)amountChanged;;
                }
                if(unitsBeingChanged[i] == arrayOfAllUnits[2])
                {
                    StaticData.numberOfArchers += (int)amountChanged;
                }
            }
        }
    }

    //Purchase the upgrade when clicked
    void OnMouseDown()
    {
        Debug.Log(resourceManager.GetSuffixIndex(costSfx) + " " + resourceManager.GetSuffixIndex(currentSfx));
        if(resourceManager.GetSuffixIndex(costSfx) < resourceManager.GetSuffixIndex(currentSfx))
        {
            BuyUpgrade();
        }
        else if(resourceManager.GetSuffixIndex(costSfx) == resourceManager.GetSuffixIndex(currentSfx) && cost <= currentResourceAmt)
        {
            BuyUpgrade();
        }
    }

    //Displays a UI for the upgrade when hovering over it
    void OnMouseEnter()
    {
        canvas.enabled = true;
    }
    
    void OnMouseExit()
    {
        canvas.enabled = false;
    }

    void SpawnPurchase()
    {

    }
}
