using UnityEngine;
using System.Collections.Generic;

public class TechTreeManager : MonoBehaviour
{
    public GameObject firstButton;
    public GameObject[] upgrades = new GameObject[1];
    Dictionary<int,GameObject> techTreePrefabs = new Dictionary<int,GameObject>();

    //Spawns the current Tech Tree setup for persistence
    //Persists scenes but not sessions at the moment, did not
    // have time to fix that before submitting project
    void Start()
    {
        for(int i=0;i<StaticData.persistentTechTree.Count;i++)
        {
            if(StaticData.persistentTechTree[i] != 0)
            {
                Instantiate(StaticData.techTreeToSpawn[i]);
            }
            
        }
    }
}
