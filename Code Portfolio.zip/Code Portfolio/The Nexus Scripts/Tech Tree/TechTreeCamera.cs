using UnityEngine;
using UnityEngine.InputSystem;

public class TechTreeCamera : MonoBehaviour
{
    public float scroll;
    public float maxZoom;
    public float minZoom;
    private Vector3 currentPos;

    void Start()
    {
        maxZoom = 5f / maxZoom;
        minZoom = 5f / minZoom;
    }

    //Lets you scroll in and out in the tech tree and move it 
    // around by clicking and dragging with your mouse
    void Update()
    {
       scroll = Mouse.current.scroll.ReadValue().y;

       if(scroll > 0 && Camera.main.orthographicSize > maxZoom)
       {
           if(Camera.main.orthographicSize - scroll > 0)
           {
               Camera.main.orthographicSize -= scroll;
           }
           else
           {
               Camera.main.orthographicSize = 1;
           }
       }
       
       if(scroll < 0 && Camera.main.orthographicSize < minZoom)
       {
           Camera.main.orthographicSize -= scroll;
       }
       if(Input.GetMouseButtonDown(0))
       {        
            currentPos = Input.mousePosition;

       }
       if(Input.GetMouseButton(0))
       {
            transform.Translate(-(Input.mousePosition-currentPos) * Time.deltaTime);
            currentPos = Input.mousePosition;

       }
    }
}
