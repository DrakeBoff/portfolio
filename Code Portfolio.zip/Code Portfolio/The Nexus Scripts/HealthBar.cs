using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    public Image background;
    public Image fill;
    public Slider bar;

    void Start()
    {
        bar = gameObject.GetComponent<Slider>();
    }

    //Updates the health on an object to show its current health compared to its maximum
    public void updateHealth(float currentHP, float maxHP)
    {
        fill.enabled = true;
        background.enabled = true;
        bar.value = currentHP / maxHP;
    }
}
