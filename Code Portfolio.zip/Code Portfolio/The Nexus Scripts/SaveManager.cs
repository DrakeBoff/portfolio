using UnityEngine;
using UnityEngine.Events;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System;


public class SaveManager : MonoBehaviour
{
    public static UnityEvent saveGame = new UnityEvent();
    private gameData currentData;
    private string filepath;
    public UnitSO[] units = new UnitSO[7]; 

    //Creates saves for the game and gets the data from the .json when first loaded
    //Works except for techTreeBought, having issues with it right now
    void Awake()
    {
        
        currentData = new gameData();
        filepath = Path.Combine(Application.persistentDataPath, "TheNexus.json");
        try
        {
            using(StreamReader reader = new StreamReader(filepath))
            {
                string dataToLoad = reader.ReadToEnd();
                currentData =  JsonUtility.FromJson<gameData>(dataToLoad);
            }   
        }
        catch(Exception)
        {
            Debug.Log("ERROR");
            currentData = new gameData();
        }
        saveGame.AddListener(SaveGame);
        StaticData.persistentTechTree = currentData.techTreeBought;
        StaticData.resourceOneAmount = currentData.resourceOneAmt;
        StaticData.resourceOneSuffix = currentData.resourceOneSfx;
        StaticData.numberOfSwordsman = currentData.numOfSwordsman;
        StaticData.numberOfArchers = currentData.numOfArchers;
        StaticData.units[0] = currentData.hero;
        StaticData.units[1] = currentData.swordsman;
        StaticData.units[2] = currentData.archer;
        StaticData.units[3] = currentData.enemySwordsman;
        StaticData.units[4] = currentData.enemyArcher;
        StaticData.units[5] = currentData.enemyTank;
        StaticData.units[6] = currentData.enemyBoss; 
    }

    void Start()
    {
        
    }

    void SaveGame()
    {
        currentData.techTreeBought = StaticData.persistentTechTree;
        currentData.resourceOneAmt = StaticData.resourceOneAmount;
        currentData.resourceOneSfx = StaticData.resourceOneSuffix;
        currentData.numOfSwordsman = StaticData.numberOfSwordsman;
        currentData.numOfArchers = StaticData.numberOfArchers;
        currentData.hero = StaticData.units[0];
        currentData.swordsman = StaticData.units[1];
        currentData.archer = StaticData.units[2];
        currentData.enemySwordsman = StaticData.units[3];
        currentData.enemyArcher = StaticData.units[4];
        currentData.enemyTank = StaticData.units[5];
        currentData.enemyBoss = StaticData.units[6];
        try
        {
            string dataString = JsonUtility.ToJson(currentData);
            using(StreamWriter writer = new StreamWriter(filepath))
            {
                writer.Write(dataString);
            }
        }
         catch(Exception)
        {
            Debug.Log("ERROR");
        }
        
    }
    


}

[System.Serializable]
public class gameData 
{
    public List<int> techTreeBought = new List<int>();
    public float resourceOneAmt = 0;
    public string resourceOneSfx = "";

    public int numOfSwordsman = 0;
    public int numOfArchers = 0;

    public UnitSO hero;
    public UnitSO swordsman;
    public UnitSO archer;
    public UnitSO enemySwordsman;
    public UnitSO enemyArcher;
    public UnitSO enemyTank;
    public UnitSO enemyBoss;
}
