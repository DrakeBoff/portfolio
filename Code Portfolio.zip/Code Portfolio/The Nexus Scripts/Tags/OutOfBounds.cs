using UnityEngine;
using System.Collections;

public class OutOfBounds : MonoBehaviour
{
    new public BoxCollider2D collider;

    void Start()
    {
        UnitUI.toggleColliders.AddListener(Toggle);
    }

    void Toggle()
    {
        StartCoroutine(ToggleCollider());
    }
    //Toggles colliders to check if units were placed correctly
    IEnumerator ToggleCollider()
    {
        collider.enabled = !collider.enabled;
        yield return new WaitForSeconds(.1f); //if its too fast it doesnt register it
        collider.enabled = !collider.enabled;
    }
}
