using UnityEngine;
using UnityEngine.SceneManagement;
public class Portal : MonoBehaviour
{
    public string teleportTo;
    //Changes scenes
    public void Teleport()
    {
        SaveManager.saveGame.Invoke();
        SceneManager.LoadScene(teleportTo);
    }
}
