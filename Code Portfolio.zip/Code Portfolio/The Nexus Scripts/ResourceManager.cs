using UnityEngine;
using System;
using System.Collections.Generic;

public class ResourceManager : MonoBehaviour
{
    public float resource1Amount;
    public string resource1Suffix;
    
    public List<string> suffix = new List<string>();

    //This class mostly just manages the resources in a much less CPU intensive format (calculates 1Q instead of 1,000,000,000,000,000)
    void Start()
    {
        suffix.Add("");
        GetList();
        resource1Amount = StaticData.resourceOneAmount;
        resource1Suffix = StaticData.resourceOneSuffix;
    }

    // Update is called once per frame
    void Update()
    {
        StaticData.resourceOneAmount = resource1Amount;
        StaticData.resourceOneSuffix = resource1Suffix;
        
        
    }
    //Creates a list of strings to go after numbers so its not having to calculate something like 10.3 e^30
    void GetList()
    {
        string tempString = "";
        //List Indices        1 2 3 4  5 6  7  8  9  10 11
        string suffixString = "k M B T Q Qi Sx Sp Oc No Dc ";
        for(int i=0; i < suffixString.Length; i++)
        {
            if(suffixString[i] == ' ')
            {
                suffix.Add(tempString);
                tempString = "";
            }
            else
            {
                tempString += suffixString[i];
            }
        }
    }

    //Returns the index that the suffix is at
    public int GetSuffixIndex(string sfx)
    {
        for(int i = 0; i<suffix.Count;i++)
        {
            if(suffix[i] == sfx){
                return i;
            }
        }
        return -1;
    }

    //Changes the amount of a certain resource that the player has
    public void ChangeResourceAmount(float amount, string suffix, int resource)
    {
        int suffixDifference;
        if(resource == 1)
        {
            suffixDifference = GetSuffixIndex(resource1Suffix) - GetSuffixIndex(suffix);
            Debug.Log("Resource1 sfx: " + GetSuffixIndex(resource1Suffix) + " Upgrade sfx: " + GetSuffixIndex(suffix));
            Debug.Log("Difference " + suffixDifference);
            amount *= (float)Math.Pow(10, -suffixDifference * 3);
            resource1Amount += amount;
            if(resource1Amount < 1)
            {
                if(GetSuffixIndex(resource1Suffix) > 0)
                {
                    resource1Suffix = ChangeResourceSuffix(resource1Suffix, -1);
                    resource1Amount *= 1000;
                }
            }
            else if(resource1Amount > 1000)
            {
                resource1Suffix = ChangeResourceSuffix(resource1Suffix, 1);
                resource1Amount /= 1000;
            }
            resource1Amount = (float)Math.Round(resource1Amount, 2);
        }
    }

    //Helper method for ChangeResourceAmount() to calculate math with different suffixes
    string ChangeResourceSuffix(string currentSuffix, int amountToChange)
    {
        
        if(GetSuffixIndex(currentSuffix) + amountToChange < 12)
        {
            return suffix[GetSuffixIndex(currentSuffix) + amountToChange];
        }
        return "RESOURCEMANAGERERROR";
    }
}
