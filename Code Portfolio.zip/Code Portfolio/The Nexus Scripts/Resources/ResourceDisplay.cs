using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class ResourceDisplay : MonoBehaviour
{
    public TMP_Text tmpText;
    public string resource;

    void Start()
    {
        
        tmpText = gameObject.GetComponent<TMP_Text>();
    }
    //Displays the current amount of each resource in the UI (only one right now)
    void Update()
    {
        if(resource == "One")
        {
            tmpText.text = StaticData.resourceOneAmount.ToString() + " " + StaticData.resourceOneSuffix;
        }
        
    }

    
}
