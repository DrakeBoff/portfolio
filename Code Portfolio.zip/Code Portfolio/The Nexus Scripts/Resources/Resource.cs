using UnityEngine;

public class Resource : MonoBehaviour
{
    //ALL SCRIPTS IN THE RESOURCE TAB ARE NOT USED IN THE PROTOTYPE AND
    //IS JUST KEPT IN CASE OF FUTURE REFERENCE
    public float moveSpeed;
    public float maxResourceHP;
    public float currentResourceHP;
    public int resource;

    public GameObject resourceManager;
    public Rigidbody2D rigid;
    public HealthBar healthBar;
    

    void Start()
    {
        resourceManager = GameObject.Find("Resource Manager");
        currentResourceHP = maxResourceHP;
        healthBar = GetComponentInChildren<HealthBar>();
        rigid = gameObject.GetComponent<Rigidbody2D>();
        rigid.AddForce(new Vector3(-moveSpeed,0,0), ForceMode2D.Impulse);
        StaticData.activeResources += 1;
    }
    
    void OnBecameInvisible()
    {
        StaticData.activeResources -= 1;
        Destroy(gameObject);
    }

    void OnMouseDown(){
        Damage(StaticData.resourceDamage);
    }
    public void Damage(float damageRecieved){
        currentResourceHP -= damageRecieved;
        healthBar.updateHealth(currentResourceHP, maxResourceHP);
        if(currentResourceHP <= 0){
            resourceManager.GetComponent<ResourceManager>().ChangeResourceAmount(StaticData.resourceOneValue, StaticData.resourceOneValueSfx, resource);
            StaticData.activeResources -= 1;
            Destroy(gameObject);
        }
    }
}
