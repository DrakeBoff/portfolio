using UnityEngine;
using System.Collections;

public class ResourceSpawner : MonoBehaviour
{
    
    //ALL SCRIPTS IN THE RESOURCE TAB ARE NOT USED IN THE PROTOTYPE AND
    //IS JUST KEPT IN CASE OF FUTURE REFERENCE
    public GameObject[] resources;
    private GameObject currentResource;

    public float spawnDelay;
    public float maxResources;
    private bool ableToSpawn = true;
    private bool tooManyResources = false;

    void Start()
    {
        ChangeResource();
    }

    void Update()
    {
        if(maxResources <= StaticData.activeResources)
        {
            tooManyResources = true;
        }
        else
        {
            tooManyResources = false;
        }
        if(tooManyResources == false && ableToSpawn == true)
        {
            SpawnResource();
        }
    }

    void SpawnResource()
    {
        Instantiate(currentResource, transform.position + new Vector3(0,Random.Range(-300,300)/ 100f,0), Quaternion.identity);
        ChangeResource();
        ableToSpawn = false;
        StartCoroutine(SpawnTimer());
    }

    void ChangeResource()
    {
        //Create the actual spawn RNG later
        currentResource = resources[0];
    }

    IEnumerator SpawnTimer()
    {
        yield return new WaitForSeconds(spawnDelay);
        ableToSpawn = true;
    }
}
