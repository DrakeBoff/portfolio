using UnityEngine;

[CreateAssetMenu(fileName = "UnitSO", menuName = "Custom/UnitSO")]
public class UnitSO : ScriptableObject
{
    //Scriptable Object for all units
    public float damage = 1;
    public float attackSpeed = 1;
    public float health = 5;
    public float moveSpeed = 1;
    public float range = 1.6f;
    public float[] resourcesDropped;
}
