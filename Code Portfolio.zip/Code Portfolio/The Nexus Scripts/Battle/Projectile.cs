using UnityEngine;

public class Projectile : MonoBehaviour
{
    public Unit unit;
    public float damage;

    //Causes damage once desired target is hit
    void OnTriggerEnter2D(Collider2D other)
    {
        if(unit != null)
        {
            if(other.gameObject == unit.currentEnemy)
            {
                Debug.Log(1);
                unit.currentEnemy.GetComponent<Unit>().Hit(damage);
                Destroy(gameObject);
            }
        }
    }
}
