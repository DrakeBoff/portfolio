using UnityEngine;
using System.Collections.Generic;

public class Wave : MonoBehaviour
{
    public List<GameObject> enemyUnits = new List<GameObject>();

    //Creates a list out of the children of the Wave gameObject
    void Start()
    {
        for (int i=0; i<transform.childCount;i++)
        {
            enemyUnits.Add(transform.GetChild(i).gameObject);
        }

    }
}
