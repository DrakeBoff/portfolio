using UnityEngine;
using System.Collections;
using TMPro;

public class PreBattleInfo : MonoBehaviour
{
    public TMP_Text warning;
    private static float currentAlpha;
    void Start()
    {
        BattleManager.battleStart.AddListener(BattleStart);
        UnitUI.placedIncorrect.AddListener(SetText);
        StartCoroutine(FadeAway());
    }
    //Fades away the error info
    IEnumerator FadeAway()
    {
        currentAlpha = 1;
        for(int i=0;i<101;i++)
        {
            warning.color = new Color(warning.color.r,warning.color.g,warning.color.b,currentAlpha);
            yield return new WaitForSeconds(.02f);
            currentAlpha -= .01f;
        }
    }
    //Displays the error info if the units are placed incorrectly
    void SetText(bool OOB)
    {
        if(OOB)
        {
            warning.text = "Place units on the left side of this line";
        }
        else
        {
            warning.text = "Don't place units on top of each other";
        }
        StartCoroutine(FadeAway());
    }
    void BattleStart()
    {
        Destroy(gameObject);
    }
}
