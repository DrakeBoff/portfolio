using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;
using System;

public class PreBattleUI : MonoBehaviour
{
    public GameObject[] units;
    public string[] nameOfUnits = new string[] {"Hero","Swordsman","Archer"};
    public List<int> numberOfUnits = new List<int>();
    public List<GameObject> unitUI = new List<GameObject>();
    
    void Start()
    {
        UnitUI.unitsChanged.AddListener(ChangeNumber);
        BattleManager.battleStart.AddListener(RemoveUI);
    }

    //Creates the UI for placing units before the battle
    public void ShowUI()
    {

        int middleIndex = units.Length / 2;
        for(int i=0;i<numberOfUnits.Count;i++)
        {
            Vector3 pos = new Vector3((i-middleIndex)*2,0,0);
            if(units.Length % 2 == 0)
            {
                pos.x += 1;
            }
            units[i].GetComponent<Unit>().UIText.text = nameOfUnits[i] + " " + numberOfUnits[i].ToString() + "x";
            unitUI.Add(Instantiate(units[i], new Vector3(0,-4,0) + pos, units[i].transform.rotation));
        }
    }
    //Helper method for ChangeNumber() to set the text of the UI object
    void UpdateText(GameObject unit)
    {
        int index = unitUI.IndexOf(unit);
        Debug.Log(units[index].GetComponent<Unit>().UIText.text = nameOfUnits[index] + " " + numberOfUnits[index].ToString() + "x");
        unitUI[index].GetComponent<Unit>().UIText.text = nameOfUnits[index] + " " + numberOfUnits[index].ToString() + "x";
    }

    //Updates the number of a unit based on how many objects are in the scene
    void ChangeNumber(GameObject unit, int amount)
    {
        int index = unitUI.IndexOf(unit);
        Debug.Log(index);
        numberOfUnits[index] += amount;
        if(numberOfUnits[index] == 0)
        {
            unitUI[index].GetComponent<BoxCollider2D>().enabled = false;
            unitUI[index].GetComponent<SpriteRenderer>().color = new Color32(191,0,11,255);
        }
        else if(numberOfUnits[index] - amount == 0)
        {
            unitUI[index].GetComponent<BoxCollider2D>().enabled = true;
            unitUI[index].GetComponent<SpriteRenderer>().color = new Color32(0,131,255,255);
        }
        Debug.Log(numberOfUnits[index]);
        UpdateText(unit);
    }

    //Destroys all of the UI when the battle is going on
    void RemoveUI()
    {
        for(int i=0;i<numberOfUnits.Count;i++)
        {
            Destroy(unitUI[i]);
        }
        Destroy(gameObject);
    }
}
