using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleOverUI : MonoBehaviour
{
    public TMP_Text result;
    public TMP_Text wavesCompleted;
    public TMP_Text resourceOneGained;
    public float[] resourcesEarned;
    
    //Displays a panel when the battle is over
    public void BattleOverSequence(bool victory, int waveNumber)
    {
        wavesCompleted.text = "Waves Completed " + waveNumber + "/10"; 
        resourceOneGained.text = resourcesEarned[0].ToString() + " " + StaticData.resourceOneSuffix;
        if(victory)
        {
            result.text = "YOU WIN!";
        }
        else
        {
            result.text = "YOU DIED";
        }
        gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector3(100,0,0);
    }
}
