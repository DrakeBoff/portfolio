using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.Events;

public class BattleManager : MonoBehaviour
{
    public int currentWaveNumber;
    public int friendliesInPosition;
    public bool combatStarted;
    public float worldScaling;

    public float[] resourcesEarned = new float[2];
    
    public int[] unitsUI;

    public PreBattleUI preBattleUI;
    public BattleOverUI battleOverUI;

    public static UnityEvent battleStart = new UnityEvent();
    public static UnityEvent<bool> battleOver = new UnityEvent<bool>();

    public List<GameObject> enemies = new List<GameObject>();
    public List<GameObject> currentWave = new List<GameObject>();
    public List<GameObject> friendlyUnits = new List<GameObject>();

    private int currentEnemies;
    private int currentFriendlies;

    public Wave wave;

    void Start()
    {
        unitsUI = new int[3] {1,StaticData.numberOfSwordsman,StaticData.numberOfArchers};
        for(int i = 0;i < unitsUI.Length; i++)
        {
            if(unitsUI[i] != 0)
            {
                preBattleUI.numberOfUnits.Add(unitsUI[i]);
            }
        }
        battleOver.AddListener(GameOver);
        currentWaveNumber = -1;
        preBattleUI.ShowUI();

    }

    // Update is called once per frame
    void Update()
    {
       if(combatStarted)
       {
           if(enemies.Count != currentEnemies || friendlyUnits.Count != currentFriendlies)
           {
               currentEnemies = enemies.Count;
               currentFriendlies = friendlyUnits.Count;
               CheckWaveCompletion();
           }
       }
    }

    //Starts the battle sequence
    public void StartBattle()
    {
        if(friendlyUnits.Count > 0)
        {
            battleStart.Invoke();
            combatStarted = true;
            friendliesInPosition = friendlyUnits.Count;
            currentFriendlies = friendlyUnits.Count;
            currentEnemies = enemies.Count;
            StartCoroutine(StartNextWave());
        }
    }

    //Gives both friendly units and enemy units each others gameObjects so they can find and attack each other
    void GiveCurrentEnemies()
    {
        
        for(int i=0;i<friendlyUnits.Count;i++)
        {
            friendlyUnits[i].GetComponent<Unit>().enemies.Clear();
            for(int j=0;j<enemies.Count;j++)
            {
                friendlyUnits[i].GetComponent<Unit>().enemies.Add(wave.enemyUnits[j]);
                enemies[j].GetComponent<Unit>().enemies.Add(friendlyUnits[i]);
            }
            friendlyUnits[i].GetComponent<Unit>().FindClosestEnemy();
        }
        for(int i=0;i<enemies.Count;i++)
        {
            enemies[i].GetComponent<Unit>().FindClosestEnemy();
        }
        
    }

    //Triggers the next wave
    public IEnumerator StartNextWave()
    {
        GameObject spawnedWave;
        if(friendliesInPosition != friendlyUnits.Count)
        {
            yield break;
        }
        currentWaveNumber++;
        spawnedWave = Instantiate(currentWave[currentWaveNumber],transform.position,Quaternion.identity);
        wave = spawnedWave.GetComponent<Wave>();
        enemies = wave.enemyUnits;
        for(int i=0;i<100;i++)
        {
            wave.gameObject.transform.position -= new Vector3(.03f,0,0);
            yield return new WaitForSeconds(.01f);
        }
        yield return new WaitForSeconds(1);
        GiveCurrentEnemies();
        friendliesInPosition = 0;
        
    }

    //Checks for one side being wiped out and either starting the next wave or Game Over
    public void CheckWaveCompletion()
    {
        bool enemiesLeft = false;
        bool friendliesLeft = false;
        foreach(GameObject enemy in enemies)
        {
            Debug.Log(enemy);
            if(enemy != null)
            {
                enemiesLeft = true;
            }
        }
        foreach(GameObject friendly in friendlyUnits)
        {
            if(friendly != null)
            {
                friendliesLeft = true;
            }
        }
        if(friendliesLeft && enemiesLeft == false)
        {
            if(currentWaveNumber == 9)
            {
                battleOver.Invoke(true);
            }
            for(int i=0; i<friendlyUnits.Count;i++)
            {
                StartCoroutine(friendlyUnits[i].GetComponent<Unit>().ReturnToOriginalPosition());
                
            }
        }
        if(friendliesLeft == false)
        {
            battleOver.Invoke(false);
        }
    }

    //Triggers when the battle is over, can be of type victory or defeat
    void GameOver(bool victory) 
    {
        SaveManager.saveGame.Invoke();
        battleOverUI.resourcesEarned = resourcesEarned;
        battleOverUI.BattleOverSequence(victory, currentWaveNumber);
    }
    
}
