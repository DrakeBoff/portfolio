using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using TMPro;

public class Unit : MonoBehaviour
{
    public float damage;
    public float attackSpeed;
    public float health;
    public float moveSpeed;
    public float range;
    public bool inCombat;
    public float maxHP;
    public float[] resourceToDrop;
    
    public Vector3 startingPosition;
    public GameObject projectile;
    private bool returning;
    private Animator animator;

    public TMP_Text UIText;
    public BattleManager battleManager;
    public Wave wave;
    public List<GameObject> enemies = new List<GameObject>();
    public GameObject currentEnemy;
    public UnitSO unit;
    public HealthBar healthBar;
    new public AudioSource audio;
    public AudioClip hitAudio;

    //Sets values to what the scripable object has
    void Start()
    {
        audio = gameObject.AddComponent<AudioSource>();
        audio.playOnAwake = false;
        audio.volume *= StaticData.SFXVolume;
        audio.clip = hitAudio;
        battleManager = GameObject.Find("Battle Manager").GetComponent<BattleManager>();
        damage = unit.damage;
        attackSpeed = unit.attackSpeed;
        health = unit.health;
        maxHP = unit.health;
        moveSpeed = unit.moveSpeed;
        range = unit.range;
        resourceToDrop = unit.resourcesDropped;
        startingPosition = transform.position;
        if(gameObject.GetComponent<EnemyUnit>())
        {
            Debug.Log("Scaling " + StaticData.enemyScaling);
            health *= StaticData.enemyScaling;
            damage *= StaticData.enemyScaling;
        }
        animator = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        if(currentEnemy != null && battleManager.combatStarted)
        {
            if(Vector3.Distance(gameObject.transform.position, currentEnemy.transform.position) < range)
            {
                if(inCombat == false)
                {
                    StartCoroutine(StartAttacking());
                }
            }
            else
            {
                transform.position = Vector3.MoveTowards(transform.position, currentEnemy.transform.position, moveSpeed * Time.deltaTime);
            }
        }
        else if(enemies.Count > 0)
        {
            FindClosestEnemy();
        }
    }
    
    //Determines the closest enemy and moves towards it
    public void FindClosestEnemy()
    {
        int closestEnemyIndex = 0;
        float closestDistance = 1000;
        float currentDistance;
        for(int i=0;i<enemies.Count;i++)
        {
            if(enemies[i] != null)
            {
                currentDistance = Vector3.Distance(gameObject.transform.position, enemies[i].transform.position);
                if(currentDistance < closestDistance)
                {
                    closestDistance = currentDistance;
                    closestEnemyIndex = i;
                }
            }
        }
        currentEnemy = enemies[closestEnemyIndex];
    }

    //Once in range, unit will stop moving and attack
    IEnumerator StartAttacking()
    {
        inCombat = true;
        Attack();
        if(currentEnemy != null)
        {
            yield return new WaitForSeconds(1/attackSpeed);
            StartCoroutine(StartAttacking());
        }
        else
        {
            FindClosestEnemy();
            inCombat = false;
        }
    }

    //Damages enemy gameObject
    void Attack()
    {
        if(currentEnemy != null)
        {
            if(range < 3)
            {
                currentEnemy.GetComponent<Unit>().Hit(damage);
            }
            else
            {
                ShootProjectile();
            }
        }
        
    }

    //Calculates damage received to the unit
    public void Hit(float damageReceived)
    {
        health -= damageReceived;
        healthBar.updateHealth(health, maxHP);
        animator.SetTrigger("Hit");
        audio.pitch = Random.Range(.5f, 2.5f);
        audio.Play();
        if(health <= 0){
            battleManager.enemies.Remove(gameObject);
            battleManager.friendlyUnits.Remove(gameObject);
            StaticData.resourceOneAmount += resourceToDrop[0];
            battleManager.resourcesEarned[0] += resourceToDrop[0];
            Destroy(gameObject);
        }
    }

    //Returns units to their starting position when the wave ends
    public IEnumerator ReturnToOriginalPosition()
    {
        int count = 0;
        while(transform.position != startingPosition)
        {
            transform.position = Vector3.MoveTowards(transform.position, startingPosition,moveSpeed * Time.deltaTime);
            count++;
            yield return new WaitForSeconds(.001f);
            if(count > 5000)
            {
                break;
            }
        }
        battleManager.friendliesInPosition++;
        StaticData.enemyScaling *= battleManager.worldScaling;
        StartCoroutine(battleManager.StartNextWave());
    }

    void ShootProjectile()
    {
        GameObject currentProjectile;
        Vector3 startPos = transform.position;
        currentProjectile = Instantiate(projectile, transform.position, Quaternion.identity);
        projectile.gameObject.GetComponent<Projectile>().unit = gameObject.GetComponent<Unit>();
        projectile.gameObject.GetComponent<Projectile>().damage = damage;
        currentProjectile.transform.position = Vector3.MoveTowards(currentProjectile.transform.position, startPos,4 * Time.deltaTime);
    }
}
