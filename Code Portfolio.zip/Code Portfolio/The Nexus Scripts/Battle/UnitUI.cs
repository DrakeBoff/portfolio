using UnityEngine;
using UnityEngine.Events;
using System.Collections;

public class UnitUI : MonoBehaviour
{
    public bool copy;
    public GameObject objectCopy;
    public GameObject objectParent;
    public bool holdingDown;
    public bool placedCorrect;

    public BattleManager battleManager;
    public static UnityEvent toggleColliders = new UnityEvent();
    public static UnityEvent<bool> placedIncorrect = new UnityEvent<bool>();
    public static UnityEvent<GameObject, int> unitsChanged = new UnityEvent<GameObject, int>();

    void Start()
    {
        battleManager = GameObject.Find("Battle Manager").GetComponent<BattleManager>();
        toggleColliders.AddListener(ToggleForToggle);
    }
    // Update is called once per frame
    void Update()
    {
       if(copy && holdingDown)
       {
            transform.position = Camera.main.ScreenToWorldPoint(Input.mousePosition + new Vector3(0,0,15));
       } 
    }
    //Creates a copy of the unit in the PreBattleUI to place on the battlefield
    void OnMouseDown()
    {
        holdingDown = true;
        if(copy == false)
        {
            objectCopy = Instantiate(gameObject);
            battleManager.friendlyUnits.Add(objectCopy);
            objectCopy.GetComponent<Unit>().UIText.enabled = false;
            objectCopy.GetComponent<UnitUI>().objectParent = gameObject;
            objectCopy.GetComponent<UnitUI>().copy = true;
            objectCopy.GetComponent<UnitUI>().holdingDown = true;
            objectCopy.GetComponent<BoxCollider2D>().enabled = false;
            holdingDown = false;
            unitsChanged.Invoke(gameObject, -1);
        }
    }
    //Drops hte unit
    void OnMouseUp()
    {
        holdingDown = false;
        if(objectCopy != null)
        {
            objectCopy.GetComponent<UnitUI>().holdingDown = false;
            objectCopy.GetComponent<Unit>().startingPosition = objectCopy.transform.position;
            toggleColliders.Invoke();
        }
    }

    //Destroys the unit if incorrectly placed
    void OnTriggerEnter2D(Collider2D other)
    {
        if(copy)
        {
            if(other.gameObject.GetComponent<OutOfBounds>())
            {
                battleManager.friendlyUnits.Remove(gameObject);
                Destroy(gameObject);
                placedIncorrect.Invoke(true);
                unitsChanged.Invoke(objectParent, 1);
            }
            if(other.gameObject.GetComponent<UnitUI>() && other.gameObject.GetComponent<UnitUI>().copy && placedCorrect == false)
            {
                battleManager.friendlyUnits.Remove(gameObject);
                Destroy(gameObject);
                placedIncorrect.Invoke(false);
                unitsChanged.Invoke(objectParent, 1);
            }
        }
    }

    //Helper for triggering Coroutine with event
    void ToggleForToggle()
    {
        StartCoroutine(ToggleCollider());
    }

    //Toggles colliders to check if placed incorrectly
    IEnumerator ToggleCollider()
    {
        if(copy)
        {
            gameObject.GetComponent<BoxCollider2D>().enabled = !gameObject.GetComponent<BoxCollider2D>().enabled;
            yield return new WaitForSeconds(.1f);
            gameObject.GetComponent<BoxCollider2D>().enabled = !gameObject.GetComponent<BoxCollider2D>().enabled;
            if(objectCopy != null)
            {
                objectCopy.GetComponent<UnitUI>().placedCorrect = true;
            }
        }
    }
}
