using UnityEngine;
using System.Collections.Generic;

public class StaticData : MonoBehaviour
{
    //Collection of all static values for organization purposes

    //public static [data type]

    //Resource Gathering
    public static int activeResources;
    public static float resourceDamage = 1;

    public static float resourceOneAmount;
    public static string resourceOneSuffix = "";
    public static float resourceOneValue;
    public static string resourceOneValueSfx = "";

    //Battle
    public static int numberOfSwordsman = 0;
    public static int numberOfArchers = 0;

    public static float enemyScaling = 1;
    public static float enemyValue = 1;

    public static UnitSO[] units = new UnitSO[7];

    //Tech Tree
    //Still WIP
    public static List<int> persistentTechTree = new List<int>();
    public static List<GameObject> techTreeToSpawn = new List<GameObject>();
    public static bool addedSavedObjects;

    //Audio
    public static float SFXVolume = 1;
    public static float musicVolume = .3f;
}
