    using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed;
    public Rigidbody2D rigid;

    public bool interact;

    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
    }

    //Basic Movement
    void FixedUpdate()
    {
        if(Input.GetKey("w"))
        {
            rigid.AddForce(new Vector3(0,moveSpeed,0));
        }
        if(Input.GetKey("a"))
        {
            rigid.AddForce(new Vector3(-moveSpeed,0,0));
        }
        if(Input.GetKey("s"))
        {
            rigid.AddForce(new Vector3(0,-moveSpeed,0));
        }
        if(Input.GetKey("d"))
        {
            rigid.AddForce(new Vector3(moveSpeed,0,0));
        }
    }

    //Allows the player to interact with the portals by pressing "E"
    void Update()
    {
        if(Input.GetKey("e"))
        {
            interact = true;
        }
        else
        {
            interact = false;
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if(other.gameObject.GetComponent<Portal>())
        {
            if(interact)
            {
                other.gameObject.GetComponent<Portal>().Teleport();
            }
        }
    }
}
