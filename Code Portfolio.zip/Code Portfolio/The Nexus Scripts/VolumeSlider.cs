using UnityEngine;
using UnityEngine.UI;

public class VolumeSlider : MonoBehaviour
{
    public bool music;
    public bool SFX;
    public float debugVolume;

    //Makes the slider values change the volume of different audio
    void Start()
    {
        if(music)
        {
            gameObject.GetComponent<Slider>().value = StaticData.musicVolume;
        }
        if(SFX)
        {
            gameObject.GetComponent<Slider>().value = StaticData.SFXVolume;
        }
    }

    void Update()
    {
        debugVolume = StaticData.musicVolume;
    }

    public void UpdateSlider()
    {
        if(music)
        {
            StaticData.musicVolume = gameObject.GetComponent<Slider>().value;
        }
        if(SFX)
        {
            StaticData.SFXVolume = gameObject.GetComponent<Slider>().value;
        }
    }
}
