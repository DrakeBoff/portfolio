using UnityEngine;
using System.Collections;

public class AudioManager : MonoBehaviour
{
    public bool battleAudio;
    public AudioClip piano;
    public AudioClip fullyScored;
    
    public float volume;
    

    public AudioSource pianoSource;
    public AudioSource fullSource;

    //Manages the audio for both adaptive(battle) and normal scenes
    void Start()
    {
        volume *= StaticData.musicVolume;
        if(battleAudio)
        {
            BattleManager.battleStart.AddListener(BattleAudioListener);
            pianoSource = gameObject.AddComponent<AudioSource>();
            fullSource = gameObject.AddComponent<AudioSource>();
            fullSource.volume = 0;
            pianoSource.volume = volume;
            pianoSource.clip = piano;
            fullSource.clip = fullyScored;
            pianoSource.Play(0);
            fullSource.Play(0);
            pianoSource.loop = true;
            fullSource.loop = true;
        }
    }

    void BattleAudioListener()
    {
        StartCoroutine(BattleAudio());
    }

    IEnumerator BattleAudio()
    {
        for(int i=0;i<100;i++)
        {
            pianoSource.volume -= volume/100;
            fullSource.volume += volume/100;
            yield return new WaitForSeconds(.04f);
        }
    }
}
