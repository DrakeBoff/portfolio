using UnityEngine;

public class PauseMenu : MonoBehaviour
{
    bool invisable = true;
    new RectTransform transform;
    public GameObject UIToMove;


    void Start()
    {
        transform = gameObject.GetComponent<RectTransform>();
    }
    void Update()
    {
        if(Input.GetKeyDown("escape"))
        {
            ToggleMenu();
        }
    }
    //Shows the Pause Menu UI while moving whatever UI elements may have been there previously
    public void ToggleMenu()
    {
        Debug.Log("Toggled Menu");
        if(invisable)
        {
            gameObject.transform.localPosition = Vector3.zero;
            invisable = false;
            if(UIToMove != null)
            {
                UIToMove.transform.localPosition = new Vector3(4000,4000,0);
            }
        }
        else
        {
            gameObject.transform.localPosition = new Vector3(4000,4000,0);
            invisable = true;
            if(UIToMove != null)
            {
                UIToMove.transform.localPosition = Vector3.zero;
            }
        }
    }
}
