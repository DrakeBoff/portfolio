using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Player player;
    public Transform playerTransform;

    private Vector3 referenceVelocity = Vector3.zero;

    public float easeTime;
    void Start()
    {
        playerTransform = player.transform;
        
    }

    // Makes camera follow player in "The Nexus" Scene
    void Update()
    {
        transform.position = Vector3.SmoothDamp(transform.position, playerTransform.position, ref referenceVelocity, easeTime);
    }
}
